import fs from 'node:fs/promises';
import path from 'node:path';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(new URL(import.meta.url).pathname);
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'outputs/E06_minimax_xml.xlsx')));
wb.recalculate();
const preview=await wb.render({sheetName:'Summary',range:'A1:M20',scale:1.25,format:'png'});
await fs.writeFile(path.join(root,'evidence/E06_july_result.png'),new Uint8Array(await preview.arrayBuffer()));
console.log((await wb.inspect({kind:'region',sheetId:'Summary',range:'A4:D12',maxChars:2200})).ndjson);
