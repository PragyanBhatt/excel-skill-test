"""Run explicit library workflows, not model/agent sessions or token benchmarks.

Both workflows implement the complete request. MiniMax uses its published pinned
unpack/edit/pack scripts. Direct openpyxl uses rich_text=True, keep_links=True,
data_only=False and explicitly handles all month-extension dependencies.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
from copy import copy
from zipfile import ZipFile
import contextlib,hashlib,importlib.util,io,json,platform,re,time,warnings
from xml.sax.saxutils import escape
import openpyxl
from openpyxl.workbook.properties import CalcProperties
from package_reader import Package
from scenarios import SCENARIOS,prompt
from grade import check
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'outputs'
def module(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/'vendor'/'minimax'/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
ROWS=[['SKU-C','Jul 2026',20,None,30],['SKU-A','Jul 2026',50,0,45],['SKU-D','Jul 2026',25,None,35],['SKU-B','Jul 2026',70,None,75]]
def july_formulas(r):
 return [f'=Inputs!A{r}',f'=Inputs!B{r}',f'=INDEX($I$5:$I$8,MATCH(A{r},$A$5:$A$8,0))',
  f'=IF(ISBLANK(Inputs!D{r}),Inputs!C{r},Inputs!D{r})',f'=Inputs!E{r}',f'=INDEX(Inputs!$I$5:$I$8,MATCH(A{r},Inputs!$G$5:$G$8,0))',
  f'=MIN(E{r},MAX(0,C{r}+D{r}-F{r}))',f'=E{r}-G{r}',f'=C{r}+D{r}-G{r}']
SUMMARY={'B5':'=SUM(Plan!G5:G12)','B6':'=SUM(Plan!H5:H12)','A7':'July ending inventory','B7':'=SUMIF(Plan!B5:B12,A12,Plan!I5:I12)',
 'A12':'Jul 2026','B12':'=SUMIF(Plan!B5:B12,A12,Plan!G5:G12)','C12':'=SUMIF(Plan!B5:B12,A12,Plan!H5:H12)','D12':'=SUMIF(Plan!B5:B12,A12,Plan!I5:I12)'}
def openpyxl_edit(key,source,output):
 with warnings.catch_warnings(record=True) as messages:
  warnings.simplefilter('always');w=openpyxl.load_workbook(source,data_only=False,keep_links=True,rich_text=True)
  s=SCENARIOS[key]
  if key!='E06':w[s['sheet']][s['cell']]=s['value']
  else:
   i,p,su=w['Inputs'],w['Plan'],w['Summary']
   for r,row in enumerate(ROWS,9):
    for c,v in enumerate(row,1):i.cell(r,c).value=v;i.cell(r,c)._style=copy(i.cell(5,c)._style)
    for c,f in enumerate(july_formulas(r),1):p.cell(r,c).value=f;p.cell(r,c)._style=copy(p.cell(5,c)._style)
   i.tables['Movements'].ref='A4:E12';p.tables['MonthlyPlan'].ref='A4:I12'
   for t in [i.tables['Movements'],p.tables['MonthlyPlan']]:
    if t.autoFilter is not None:t.autoFilter.ref=t.ref
   for cell,value in SUMMARY.items():su[cell]=value
   for c in range(1,5):su.cell(12,c)._style=copy(su.cell(11,c)._style)
   w.defined_names['ReportingMonths'].attr_text='Summary!$A$11:$A$12';w.defined_names['FulfilledUnits'].attr_text='Summary!$B$11:$B$12'
   for dv in i.data_validations.dataValidation:
    if str(dv.sqref)=='A5:A8':dv.sqref='A5:A12'
    elif str(dv.sqref)=='C5:E8':dv.sqref='C5:E12'
   original=list(p.conditional_formatting)
   for cf in original:
    if str(cf.sqref)=='H5:H8':
     rules=list(p.conditional_formatting[cf]);del p.conditional_formatting[str(cf.sqref)]
     for rule in rules:p.conditional_formatting.add('H5:H12',rule)
   for ser in su._charts[0].series:
    if ser.cat is not None:
     ref=ser.cat.numRef or ser.cat.strRef
     if ref is not None:ref.f="'Summary'!$A$11:$A$12"
    if ser.val is not None and ser.val.numRef is not None:
     col='B' if '$B$11' in ser.val.numRef.f else 'C';ser.val.numRef.f=f"'Summary'!${col}$11:${col}$12"
  w.calculation=CalcProperties(calcMode='auto',fullCalcOnLoad=True,forceFullCalc=True);w.save(output)
 return [str(x.message) for x in messages]
def cell_match(text,addr):
 pat=r'<(?P<p>\w+:)?c\b(?=[^>]*\br="'+re.escape(addr)+r'")[^>]*(?:/>|>.*?</(?:\w+:)?c>)'
 m=re.search(pat,text,re.S)
 if not m:raise ValueError('Missing preformatted source cell '+addr)
 return m
def set_cell(text,addr,value,style_from=None):
 m=cell_match(text,addr);p=m['p'] or '';style=re.search(r'\bs="(\d+)"',cell_match(text,style_from).group(0) if style_from else m.group(0));sty=' s="'+style[1]+'"' if style else ''
 if isinstance(value,str) and value.startswith('='):body='<'+p+'f>'+escape(value[1:])+'</'+p+'f><'+p+'v/>';typ=''
 elif isinstance(value,str):body='<'+p+'is><'+p+'t>'+escape(value)+'</'+p+'t></'+p+'is>';typ=' t="inlineStr"'
 elif value is None:body='';typ=''
 else:body='<'+p+'v>'+str(value)+'</'+p+'v>';typ=' t="n"'
 new='<'+p+'c r="'+addr+'"'+sty+typ+'>'+body+'</'+p+'c>'
 return text[:m.start()]+new+text[m.end():]
def invalidate_formula_caches(text):
 def clear(m):
  c=m[0]
  if re.search(r'<(?:\w+:)?f(?:\s|>|/)',c):c=re.sub(r'<(?:\w+:)?v\b[^>]*(?:/>|>.*?</(?:\w+:)?v>)','',c,flags=re.S)
  return c
 return re.sub(r'<(?:\w+:)?c\b[^>]*>.*?</(?:\w+:)?c>',clear,text,flags=re.S)
def request_recalc(text):
 m=re.search(r'<(?P<p>\w+:)?calcPr\b[^>]*/>',text)
 if m:
  tag=re.sub(r'\s(?:calcMode|fullCalcOnLoad|forceFullCalc)="[^"]*"','',m[0]);tag=tag[:-2]+' calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/>'
  return text[:m.start()]+tag+text[m.end():]
 closing=re.search(r'</(?P<p>\w+:)?workbook>',text);p=closing['p'] or '';return text[:closing.start()]+'<'+p+'calcPr calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/>'+text[closing.start():]
def xml_edit(key,source,output):
 log=io.StringIO()
 with TemporaryDirectory(prefix=key+'-',dir=OUT) as folder:
  folder=Path(folder)
  with contextlib.redirect_stdout(log):module('xlsx_unpack').unpack(str(source),str(folder))
  s=SCENARIOS[key];paths={n:folder/p for n,_,p in Package(source).sheets}
  if key!='E06':
   t=paths[s['sheet']];t.write_text(set_cell(t.read_text(),s['cell'],s['value']))
  else:
   for sheet in ['Inputs','Plan']:
    file=paths[sheet];text=file.read_text()
    for r,row in enumerate(ROWS,9):
     values=row if sheet=='Inputs' else july_formulas(r)
     for c,v in zip('ABCDE' if sheet=='Inputs' else 'ABCDEFGHI',values):text=set_cell(text,f'{c}{r}',v,style_from=f'{c}5')
    if sheet=='Inputs':text=text.replace('sqref="A5:A8"','sqref="A5:A12"').replace('sqref="C5:E8"','sqref="C5:E12"')
    else:text=text.replace('sqref="H5:H8"','sqref="H5:H12"')
    file.write_text(text)
   file=paths['Summary'];text=file.read_text()
   for addr,v in SUMMARY.items():text=set_cell(text,addr,v,style_from=addr[0]+'11' if addr.endswith('12') else None)
   file.write_text(text)
   for t in (folder/'xl'/'tables').glob('*.xml'):
    text=t.read_text().replace('ref="A4:E8"','ref="A4:E12"').replace('ref="A4:I8"','ref="A4:I12"');t.write_text(text)
   for t in (folder/'xl').rglob('chart*.xml'):
    text=t.read_text()
    text=re.sub(r'(<(?:\w+:)?f>)([^<]*\$([ABC])\$11)(</(?:\w+:)?f>)',lambda m:m[1]+m[2]+':$'+m[3]+'$12'+m[4],text)
    # Discard stale chart caches; the range bindings drive Excel refresh.
    text=re.sub(r'<(?P<p>\w+:)?(?:numCache|strCache)\b[^>]*>.*?</(?:\w+:)?(?:numCache|strCache)>','',text,flags=re.S)
    t.write_text(text)
   t=folder/'xl'/'workbook.xml';t.write_text(t.read_text().replace('Summary!$A$11:$A$11','Summary!$A$11:$A$12').replace('Summary!$B$11:$B$11','Summary!$B$11:$B$12'))
  for t in (folder/'xl'/'worksheets').glob('*.xml'):t.write_text(invalidate_formula_caches(t.read_text()))
  t=folder/'xl'/'workbook.xml';t.write_text(request_recalc(t.read_text()))
  with contextlib.redirect_stdout(log):module('xlsx_pack').pack(str(folder),str(output))
 (ROOT/'evidence'/(key+'_minimax.log')).write_text(log.getvalue())
 return []
def run():
 OUT.mkdir(exist_ok=True);results={'scope':'Deterministic workflow comparison; not an OpenCode agent A/B, not OfficeCLI, not Microsoft Excel UI execution. Script times are not agent latency.','python':platform.python_version(),'openpyxl':openpyxl.__version__,'minimax_commit':'60aaae52bb2af8162732751a4332f62a5fef518b','scenarios':{}}
 for key,s in SCENARIOS.items():
  source=ROOT/'fixtures'/(s['stem']+'.xlsx');digest=hashlib.sha256(source.read_bytes()).hexdigest();record={'title':s['title'],'source_sha256':digest,'workflows':{}}
  (ROOT/'prompts'/(key+'.md')).write_text(prompt(key))
  for arm,editor in [('openpyxl_complete',openpyxl_edit),('minimax_xml',xml_edit)]:
   dest=OUT/(key+'_'+arm+'.xlsx');start=time.perf_counter()
   try:
    warn=editor(key,source,dest);seconds=time.perf_counter()-start;graded=check(key,source,dest)
    record['workflows'][arm]={'file':dest.name,'script_execution_seconds':seconds,'warnings':warn,**graded}
   except Exception as e:record['workflows'][arm]={'file':dest.name,'pass':False,'error':str(e)}
  assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
  results['scenarios'][key]=record
 (ROOT/'comparison_results.json').write_text(json.dumps(results,indent=2))
 for key,r in results['scenarios'].items():
  print(key,{a:{'pass':v['pass'],'checks':str(v.get('passed_checks'))+'/'+str(v.get('total_checks')),'failed':[x['requirement'] for x in v.get('checks',[]) if not x['passed']],'error':v.get('error'),'warnings':v.get('warnings',[])} for a,v in r['workflows'].items()})
if __name__=='__main__':run()
