"""Independent OOXML package reader. Does not import openpyxl or MiniMax.

Shared parsing utilities for grade.py; contains no workbook editing operations.
Formula caches may change. Namespace-prefix and indentation differences are
ignored; native feature content is checked independently of worksheet values.
"""
from collections import Counter
from pathlib import PurePosixPath
from zipfile import ZipFile
import copy
import json
import posixpath
import sys
import xml.etree.ElementTree as ET

S = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P = 'http://schemas.openxmlformats.org/package/2006/relationships'
X14 = 'http://schemas.microsoft.com/office/spreadsheetml/2009/9/main'
XM = 'http://schemas.microsoft.com/office/excel/2006/main'
NS = {'s': S, 'r': R, 'x14': X14, 'xm': XM}


def canonical(node):
    if node is None:
        return None
    text = node.text or ''
    # Only ignore formatting whitespace added between XML elements.
    if not text.strip() and node.tag not in {f'{{{S}}}t', f'{{{S}}}v'}:
        text = ''
    return (node.tag, tuple(sorted(node.attrib.items())), text,
            tuple(canonical(child) for child in node))


class Package:
    def __init__(self, path):
        with ZipFile(path) as z:
            self.parts = {name: z.read(name) for name in z.namelist()}
        self.xml = {name: ET.fromstring(data) for name, data in self.parts.items()
                    if name.endswith(('.xml', '.rels', '.vml'))}
        workbook = self.xml['xl/workbook.xml']
        rels = self.xml['xl/_rels/workbook.xml.rels']
        mapping = {n.attrib['Id']: self.target('xl/workbook.xml', n.attrib['Target'])
                   for n in rels}
        self.sheets = [(n.attrib['name'], n.attrib.get('state', 'visible'),
                        mapping[n.attrib[f'{{{R}}}id']])
                       for n in workbook.find('s:sheets', NS)]
        self.sheet_trees = {name: self.xml[part] for name, _, part in self.sheets}
        strings = self.xml.get('xl/sharedStrings.xml')
        self.strings = [''.join(t.text or '' for t in n.findall('.//s:t', NS))
                        for n in strings] if strings is not None else []

    @staticmethod
    def target(owner, target):
        return (target.lstrip('/') if target.startswith('/') else
                posixpath.normpath(posixpath.join(posixpath.dirname(owner), target)))

    def cell_map(self):
        out = {}
        for name, tree in self.sheet_trees.items():
            for cell in tree.findall('.//s:sheetData/s:row/s:c', NS):
                f = cell.find('s:f', NS)
                if f is not None:
                    value = ('formula', canonical(f))
                else:
                    v = cell.find('s:v', NS)
                    typ = cell.attrib.get('t', 'n')
                    if typ == 's':
                        value = ('text', self.strings[int(v.text)])
                    elif typ == 'inlineStr':
                        value = ('text', ''.join(t.text or '' for t in cell.findall('.//s:t', NS)))
                    elif typ == 'str':
                        value = ('text', v.text if v is not None else '')
                    else:
                        value = (typ, v.text if v is not None else None)
                out[(name, cell.attrib['r'])] = value
        return out

    def feature(self, tag):
        out = {}
        for name, tree in self.sheet_trees.items():
            nodes = copy.deepcopy(tree.findall(f's:{tag}', NS))
            for node in nodes:
                for child in node.iter():
                    if tag == 'dataValidations':
                        for key in ['allowBlank','showDropDown','showErrorMessage','showInputMessage']:
                            if child.attrib.get(key) in {'0','false'}:
                                child.attrib.pop(key)
                    if tag == 'cols' and child.attrib.get('hidden') in {'0','false'}:
                        child.attrib.pop('hidden')
                    if tag == 'sheetViews':
                        for selection in list(child):
                            if selection.tag == f'{{{S}}}selection':
                                child.remove(selection)
            out[name] = tuple(canonical(n) for n in nodes)
        return out

    def sparklines(self):
        return {name: tuple(canonical(n) for n in tree.findall('.//x14:sparklineGroups', NS))
                for name, tree in self.sheet_trees.items()}

    def sparkline_count(self):
        return sum(len(tree.findall('.//x14:sparkline', NS)) for tree in self.sheet_trees.values())

    def tables(self):
        return {tree.attrib['name']: canonical(tree) for path, tree in self.xml.items()
                if tree.tag == f'{{{S}}}table'}

    def charts_and_drawings(self):
        charts = sorted((canonical(tree) for path, tree in self.xml.items()
                         if tree.tag.endswith('}chartSpace')), key=str)
        drawings = []
        for path, tree in self.xml.items():
            if tree.tag.endswith('}wsDr'):
                # Relationship ids may be regenerated; targets are checked
                # separately by chart payloads, so normalize those ids only.
                tree = copy.deepcopy(tree)
                for n in tree.iter():
                    if f'{{{R}}}id' in n.attrib:
                        n.attrib[f'{{{R}}}id'] = '<relationship>'
                drawings.append(canonical(tree))
        return charts, sorted(drawings, key=str)

    def chart_geometry(self):
        ns={'xdr':'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing'}
        geometry=[]
        for tree in self.xml.values():
            if tree.tag.endswith('}wsDr'):
                for anchor in tree:
                    geometry.append((anchor.tag,tuple(canonical(n) for n in anchor
                        if n.tag.split('}')[-1] in {'from','to','pos','ext'})))
        return sorted(geometry,key=str)

    def chart_content(self):
        C='http://schemas.openxmlformats.org/drawingml/2006/chart'
        A='http://schemas.openxmlformats.org/drawingml/2006/main'
        cn={'c':C,'a':A}
        out=[]
        for tree in self.xml.values():
            if not tree.tag.endswith('}chartSpace'):
                continue
            title=''.join(n.text or '' for n in tree.findall('.//c:title//a:t',cn))
            refs=tuple(n.text for n in tree.findall('.//c:f',cn))
            series=[]
            for ser in tree.findall('.//c:ser',cn):
                sp = ser.find('c:spPr',cn)
                # A default solid line alone has the same meaning as absent spPr.
                if sp is not None and not sp.attrib and len(sp)==1:
                    ln=sp.find('a:ln',cn)
                    if ln is not None and not ln.attrib and len(ln)==1:
                        dash=ln.find('a:prstDash',cn)
                        if dash is not None and dash.attrib=={'val':'solid'}:sp=None
                series.append((canonical(sp),canonical(ser.find('c:smooth',cn)),
                    canonical(ser.find('c:marker/c:symbol',cn))))
            axes=[]
            for axis in tree.findall('.//c:catAx',cn)+tree.findall('.//c:valAx',cn):
                axes.append((axis.tag,canonical(axis.find('c:axPos',cn)),
                    axis.find('c:numFmt',cn).attrib.get('formatCode') if axis.find('c:numFmt',cn) is not None else None,
                    tuple(canonical(n) for n in axis.findall('.//a:latin',cn))))
            out.append((title,refs,tuple(series),tuple(axes)))
        return sorted(out,key=str)

    def styles(self):
        style = self.xml['xl/styles.xml']
        num_formats={int(n.attrib['numFmtId']): n.attrib['formatCode']
                     for n in style.findall('s:numFmts/s:numFmt',NS)}
        # Built-in formats used by this fixture. Custom formats are compared
        # by their code, so valid ID remapping does not cause a failure.
        builtins={0:'General',1:'0',2:'0.00',3:'#,##0',4:'#,##0.00',9:'0%',10:'0.00%',49:'@'}
        xfs=style.find('s:cellXfs',NS)
        def unordered(element):
            if element is None:return None
            element=copy.deepcopy(element)
            for child in element.iter():
                if child.tag == f'{{{S}}}patternFill' and child.attrib.get('patternType') == 'none':
                    child.attrib.pop('patternType')
                if child.tag in {f'{{{S}}}b',f'{{{S}}}i'} and child.attrib.get('val') in {'1','true'}:
                    child.attrib.pop('val')
            return (element.tag,tuple(sorted(element.attrib.items())),
                    tuple(sorted((canonical(c) for c in element),key=str)))
        resolved=[]
        for xf in xfs:
            fmtid=int(xf.attrib.get('numFmtId','0'))
            fmt=num_formats.get(fmtid,builtins.get(fmtid,('builtin',fmtid)))
            font=style.find('s:fonts',NS)[int(xf.attrib.get('fontId','0'))]
            fill=style.find('s:fills',NS)[int(xf.attrib.get('fillId','0'))]
            border=style.find('s:borders',NS)[int(xf.attrib.get('borderId','0'))]
            resolved.append((fmt,unordered(font),unordered(fill),unordered(border),
                             canonical(xf.find('s:alignment',NS)),canonical(xf.find('s:protection',NS))))
        self.resolved_styles = resolved
        return {(name,c.attrib['r']):resolved[int(c.attrib.get('s','0'))]
                for name,tree in self.sheet_trees.items()
                for c in tree.findall('.//s:sheetData/s:row/s:c',NS)}

    def names(self):
        return canonical(self.xml['xl/workbook.xml'].find('s:definedNames', NS))

    def notes(self):
        comments = sorted((canonical(tree) for path, tree in self.xml.items()
                           if tree.tag == f'{{{S}}}comments'), key=str)
        boxes = sorted((canonical(tree) for path, tree in self.xml.items()
                        if path.endswith('.vml')), key=str)
        return comments, boxes

