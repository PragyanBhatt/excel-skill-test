"""Negative controls: prove that the grader detects deliberate corruption."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from tempfile import TemporaryDirectory
import json,re,xml.etree.ElementTree as E
from grade import check
from scenarios import SCENARIOS
from run_workflows import set_cell
ROOT=Path(__file__).resolve().parent
def corrupt(src,dst,kind):
 with ZipFile(src) as zi,ZipFile(dst,'w',ZIP_DEFLATED) as zo:
  for n in zi.namelist():
   data=zi.read(n)
   if kind=='thread' and 'threadedcomment' in n.lower():continue
   if kind=='connection' and n=='xl/connections.xml':continue
   if kind=='validation' and n=='xl/worksheets/sheet1.xml':
    text=data.decode();text=re.sub(r'<(?:\w+:)?extLst\b[^>]*>.*?</(?:\w+:)?extLst>','',text,flags=re.S);data=text.encode()
   if kind=='pivot_layout' and n=='xl/pivotTables/pivotTable1.xml':
    text=data.decode();text=re.sub(r'<(?:\w+:)?extLst\b[^>]*>.*?</(?:\w+:)?extLst>','',text,flags=re.S);data=text.encode()
   if kind=='data_table' and n=='xl/worksheets/sheet1.xml':
    text=data.decode();text=re.sub(r'<(?:\w+:)?f\b[^>]*t="dataTable"[^>]*/>','',text);data=text.encode()
   if kind=='zero' and n=='xl/worksheets/sheet1.xml':data=set_cell(data.decode(),'D10',None).encode()
   if kind=='wrong_carry' and n=='xl/worksheets/sheet2.xml':data=set_cell(data.decode(),'C9','=I8').encode()
   if kind=='stale_table' and n=='xl/tables/table1.xml':data=data.decode().replace('A4:E12','A4:E8').encode()
   if kind=='wrong_rate' and n=='xl/worksheets/sheet1.xml':data=set_cell(data.decode(),'B5',0.08).encode()
   zo.writestr(n,data)
def run():
 cases=[('E01','thread'),('E02','connection'),('E03','validation'),('E04','pivot_layout'),('E05','data_table'),('E06','zero'),('E06','wrong_carry'),('E06','stale_table'),('E07','wrong_rate')]
 results=[]
 with TemporaryDirectory(dir=ROOT/'evidence',prefix='grader-tests-') as directory:
  for key,s in SCENARIOS.items():
   assert check(key,ROOT/'fixtures'/(s['stem']+'.xlsx'),ROOT/'outputs'/(key+'_minimax_xml.xlsx'))['pass'],key
  for key,kind in cases:
   src=ROOT/'outputs'/(key+'_minimax_xml.xlsx');dest=Path(directory)/(key+'_'+kind+'.xlsx');corrupt(src,dest,kind)
   r=check(key,ROOT/'fixtures'/(SCENARIOS[key]['stem']+'.xlsx'),dest);assert not r['pass'],(key,kind)
   results.append({'scenario':key,'corruption':kind,'detected':True,'failed_checks':[x['requirement'] for x in r['checks'] if not x['passed']]})
 (ROOT/'grader_selftest.json').write_text(json.dumps({'pass':True,'known_good_controls':7,'negative_controls':results},indent=2));print('7 known-good workbooks and 9 deliberate corruptions verified.')
if __name__=='__main__':run()
