"""Add native feature regression components without a lossy workbook rewrite."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import copy,hashlib,json,re,xml.etree.ElementTree as E
ROOT=Path(__file__).resolve().parent
F=ROOT/'fixtures'; V=ROOT/'vendor'/'libreoffice'
S='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
R='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
P='http://schemas.openxmlformats.org/package/2006/relationships'
C='http://schemas.openxmlformats.org/package/2006/content-types'
E.register_namespace('x',S);E.register_namespace('r',R)
def read(p):
 with ZipFile(p) as z:return {n:z.read(n) for n in z.namelist() if not n.endswith('/')}
def write(p,d):
 with ZipFile(p,'w',ZIP_DEFLATED) as z:
  for n,b in d.items():z.writestr(n,b)
def xml(e):return E.tostring(e,encoding='utf-8',xml_declaration=True)
def insert_close(text,tag,content):
 m=re.search(r'</(?P<p>\w+:)?'+tag+r'>',text);assert m,tag
 return text[:m.start()]+content+text[m.start():]
def names(d,entries):
 w=d['xl/workbook.xml'].decode();prefix=re.search(r'<(\w+:)?workbook\b',w).group(1) or ''
 body='<'+prefix+'definedNames>'+''.join('<'+prefix+'definedName name="'+n+'">'+v+'</'+prefix+'definedName>' for n,v in entries)+'</'+prefix+'definedNames>'
 d['xl/workbook.xml']=insert_close(w,'workbook',body).encode()
# Extended validation: use an Excel-authored x14 component, adapt four ranges.
p=F/'E03_hr_validation.xlsx';d=read(p);orig=read(V/'data_validation_test.xlsx')
r=E.fromstring(orig['xl/worksheets/sheet1.xml']);ext=copy.deepcopy(r.find('{'+S+'}extLst'))
XM='http://schemas.microsoft.com/office/excel/2006/main';X14='http://schemas.microsoft.com/office/spreadsheetml/2009/9/main'
rules=ext.findall('.//{'+X14+'}dataValidation')
for rule,destination,formula in zip(rules,['A6','A7','B6','B7'],['Lists!$A$2:$A$4','Lists!$A$2:$A$4','INDIRECT(Lists!$A$1)','INDIRECT(OFFSET(Lists!$A$1,0,1))']):
 rule.find('{'+XM+'}sqref').text=destination
 rule.find('{'+X14+'}formula1/{'+XM+'}f').text=formula
 # Named INDIRECT dropdowns deliberately use the source's two supported mechanisms.
 if destination=='B6':rule.find('{'+X14+'}formula1/{'+XM+'}f').text='INDIRECT(Lists!$B$1)'
 if destination=='B7':rule.find('{'+X14+'}formula1/{'+XM+'}f').text='INDIRECT(OFFSET(Lists!$A$1,0,1))'
d['xl/worksheets/sheet1.xml']=insert_close(d['xl/worksheets/sheet1.xml'].decode(),'worksheet',E.tostring(ext,encoding='unicode')).encode()
names(d,[('Regions','Lists!$A$2:$A$4'),('CostCenters','Lists!$B$2:$B$4')]);write(p,d)
# Offline ERP CSV connection, native query table and table relationship.
p=F/'E02_erp_connection.xlsx';d=read(p)
connections=E.fromstring(read(V/'queryTableExport.xlsx')['xl/connections.xml'])
for child in list(connections)[1:]:connections.remove(child)
con=connections[0];con.attrib.update(name='ERPReceivablesCSV',background='0',saveData='1');con.attrib.pop('deleted',None)
text=con.find('{'+S+'}textPr');text.attrib={'sourceFile':'erp_receivables.csv','comma':'1','firstRow':'1'}
fields=text.find('{'+S+'}textFields');fields.attrib['count']='4'
for child in list(fields):fields.remove(child)
for i in range(4):E.SubElement(fields,'{'+S+'}textField')
d['xl/connections.xml']=xml(connections)
query=E.fromstring(read(V/'queryTableExport.xlsx')['xl/queryTables/queryTable1.xml']);query.attrib.update(name='ERPReceivables',connectionId='1',backgroundRefresh='0',refreshOnLoad='0')
refresh=E.SubElement(query,'{'+S+'}queryTableRefresh',nextId='5')
qfields=E.SubElement(refresh,'{'+S+'}queryTableFields',count='4')
for i,name in enumerate(['Invoice','Region','Gross SAR','Paid SAR'],1):E.SubElement(qfields,'{'+S+'}queryTableField',id=str(i),name=name,tableColumnId=str(i))
d['xl/queryTables/queryTable1.xml']=xml(query)
table=E.fromstring(d['xl/tables/table1.xml']);table.attrib.update(tableType='queryTable',connectionId='1')
for i,c in enumerate(table.find('{'+S+'}tableColumns'),1):c.set('queryTableFieldId',str(i))
d['xl/tables/table1.xml']=xml(table)
rels=E.Element('{'+P+'}Relationships');E.SubElement(rels,'{'+P+'}Relationship',Id='ERPQuery',Type=R+'/queryTable',Target='../queryTables/queryTable1.xml')
d['xl/tables/_rels/table1.xml.rels']=xml(rels)
wr=E.fromstring(d['xl/_rels/workbook.xml.rels']);E.SubElement(wr,'{'+P+'}Relationship',Id='ERPConnections',Type=R+'/connections',Target='connections.xml');d['xl/_rels/workbook.xml.rels']=xml(wr)
ct=E.fromstring(d['[Content_Types].xml'])
for part,kind in [('/xl/connections.xml','connections'),('/xl/queryTables/queryTable1.xml','queryTable')]:E.SubElement(ct,'{'+C+'}Override',PartName=part,ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.'+kind+'+xml')
d['[Content_Types].xml']=xml(ct);write(p,d)
(F/'erp_receivables.csv').write_text('Invoice,Region,Gross SAR,Paid SAR\nINV-1001,East,100000,60000\nINV-1002,West,80000,80000\nINV-1003,East,120000,20000\nINV-1004,North,90000,40000\n')
# Preserve the original Excel-authored PivotTable/cache. Add an independent assumptions tab.
d=read(V/'PivotTable_CachedDefinitionAndDataInSync.xlsx');base=read(F/'E04_pivot_control_base.xlsx')
broot=E.fromstring(base['xl/worksheets/sheet1.xml']);sst=E.fromstring(base['xl/sharedStrings.xml']);strings=[''.join(t.text or '' for t in si.findall('.//{'+S+'}t')) for si in sst]
for c in broot.findall('.//{'+S+'}c'):
 c.attrib.pop('s',None)
 if c.get('t')=='s':
  value=strings[int(c.find('{'+S+'}v').text)];c.remove(c.find('{'+S+'}v'));c.set('t','inlineStr');E.SubElement(E.SubElement(c,'{'+S+'}is'),'{'+S+'}t').text=value
d['xl/worksheets/sheet3.xml']=xml(broot)
# Retain original namespace declarations used by markup compatibility on workbook root.
w=d['xl/workbook.xml'].decode();w=w.replace('</sheets>','<sheet name="Assumptions" sheetId="4" r:id="BenchmarkAssumptions"/></sheets>');d['xl/workbook.xml']=w.encode()
r=E.fromstring(d['xl/_rels/workbook.xml.rels']);E.SubElement(r,'{'+P+'}Relationship',Id='BenchmarkAssumptions',Type=R+'/worksheet',Target='worksheets/sheet3.xml');d['xl/_rels/workbook.xml.rels']=xml(r)
c=E.fromstring(d['[Content_Types].xml']);E.SubElement(c,'{'+C+'}Override',PartName='/xl/worksheets/sheet3.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');d['[Content_Types].xml']=xml(c)
write(F/'E04_pivot_control.xlsx',d);(F/'E04_pivot_control_base.xlsx').unlink()
# Workbook-level dependencies for month extension.
p=F/'E06_supply_month_extension.xlsx';d=read(p);names(d,[('StockSKUs','Inputs!$G$5:$G$8'),('ReportingMonths','Summary!$A$11:$A$11'),('FulfilledUnits','Summary!$B$11:$B$11')]);write(p,d)
manifest={'minimax_commit':'60aaae52bb2af8162732751a4332f62a5fef518b','fixtures':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(F.glob('*.xlsx'))},'component_sources':[]}
for p in sorted(V.glob('*.xlsx')):manifest['component_sources'].append({'file':p.name,'repository':'LibreOffice/core','path':'sc/qa/unit/data/xlsx/'+p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'license':'MPL-2.0; see vendor/libreoffice/COPYING.MPL'})
(ROOT/'fixture_manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest['fixtures'],indent=2))
