import fs from 'node:fs/promises';
import path from 'node:path';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(new URL(import.meta.url).pathname);
const results={engine:'Artifact Tool',scope:'Independent arithmetic oracle and a second spreadsheet engine; not Microsoft Excel execution.',files:{},pass:true};
for(const [label,file] of [['source','fixtures/E05_capex_sensitivity.xlsx'],['openpyxl','outputs/E05_openpyxl_complete.xlsx'],['minimax_xml','outputs/E05_minimax_xml.xlsx']]){
 const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,file)));
 const sheet=wb.worksheets.getItem('Sensitivity');const states={};
 for(const price of [135,140]){
  sheet.getRange('B7').values=[[price]];wb.recalculate();
  const actual=sheet.getRange('F5:H7').values;
  const expected=[8000,10000,12000].map(units=>[0.2,0.25,0.3].map(margin=>units*price*margin-150000));
  const pass=actual.every((row,r)=>row.every((v,c)=>typeof v==='number'&&Math.abs(v-expected[r][c])<1e-6));
  states[price]={pass,actual,expected};results.pass &&=pass;
 }
 results.files[label]=states;
}
await fs.writeFile(path.join(root,'sensitivity_second_engine.json'),JSON.stringify(results,null,2));console.log(JSON.stringify(results));
