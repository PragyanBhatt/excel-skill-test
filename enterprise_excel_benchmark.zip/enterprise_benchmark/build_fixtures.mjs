import fs from 'node:fs/promises';
import path from 'node:path';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const root=path.dirname(new URL(import.meta.url).pathname);
const out=path.join(root,'fixtures');
await fs.mkdir(out,{recursive:true});
function setup(names){
 const wb=Workbook.create();
 for(const name of names){const s=wb.worksheets.add(name);s.showGridLines=false;
  s.getRange('A1:M36').format.font={name:'Arial',size:10,color:'#243449'};
  s.getRange('A:M').format.columnWidth=15;s.getRange('A:A').format.columnWidth=27;
  s.getRange('A1').format.font={name:'Arial',size:17,bold:true,color:'#17365D'};
  s.getRange('A1:M36').format.rowHeight=23;
 }
 return wb;
}
function header(s,r){s.getRange(r).format={fill:'#17365D',font:{name:'Arial',bold:true,color:'#FFFFFF'}};}
function input(s,r){s.getRange(r).format.fill='#FFF2CC';s.getRange(r).format.font.color='#0000FF';}
async function save(wb,id,sheet,range){wb.recalculate();const x=await SpreadsheetFile.exportXlsx(wb);await x.save(path.join(out,id+'.xlsx'));
 const png=await wb.render({sheetName:sheet,range,scale:1.25,format:'png'});
 await fs.writeFile(path.join(root,'evidence',id+'_source.png'),new Uint8Array(await png.arrayBuffer()));
 console.log(id);
}
{
 const w=setup(['Budget','Actuals']),s=w.worksheets.getItem('Budget'),a=w.worksheets.getItem('Actuals');
 s.getRange('A1').values=[['Department budget approval']];s.getRange('A2').values=[['Fictional SAR. Existing approval discussion must survive.']];
 s.getRange('A4:B4').values=[['Input / output','SAR']];header(s,'A4:B4');
 s.getRange('A5:B7').values=[['Approved travel budget',120000],['Posted travel spend',null],['Available budget',null]];
 a.getRange('A1').values=[['Posted travel expenses']];a.getRange('A4:B8').values=[['Month','Posted spend'],['Mar',15000],['Apr',18000],['May',22000],['Jun',26000]];
 header(a,'A4:B4');a.tables.add('A4:B8',true,'PostedTravel');
 s.getRange('B6:B7').formulas=[['=SUM(Actuals!B5:B8)'],['=B5-B6']];s.getRange('B5:B7').setNumberFormat('#,##0');input(s,'B5');
 w.comments.setSelf({displayName:'Finance approver (fictional)'});
 const t=w.comments.addThread({cell:s.getRange('B5')},'Approved baseline travel budget: SAR 120,000. Retain this approval history.');
 t.addReply('Operations requested an increase to SAR 135,000. Update the input only; keep this discussion.');
 await save(w,'E01_budget_approvals','Budget','A1:D10');
}
{
 const w=setup(['ERPExtract','Report']),s=w.worksheets.getItem('ERPExtract'),r=w.worksheets.getItem('Report');
 s.getRange('A1').values=[['ERP receivables extract']];s.getRange('A2').values=[['Offline CSV connection fixture; no enterprise credentials.']];
 s.getRange('A4:D8').values=[['Invoice','Region','Gross SAR','Paid SAR'],['INV-1001','East',100000,60000],['INV-1002','West',80000,80000],['INV-1003','East',120000,20000],['INV-1004','North',90000,40000]];
 header(s,'A4:D4');s.tables.add('A4:D8',true,'ERPReceivables');s.getRange('C5:D8').setNumberFormat('#,##0');s.freezePanes.freezeRows(4);
 r.getRange('A1').values=[['Receivables risk report']];r.getRange('A4:B4').values=[['Input / output','Value']];header(r,'A4:B4');
 r.getRange('A5:B8').values=[['Reserve rate',0.02],['Gross receivables',null],['Open receivables',null],['Risk reserve (SAR)',null]];input(r,'B5');r.getRange('B5').setNumberFormat('0.0%');
 r.getRange('B6:B8').formulas=[['=SUM(ERPExtract!C5:C8)'],['=B6-SUM(ERPExtract!D5:D8)'],['=B7*B5']];r.getRange('B6:B8').setNumberFormat('#,##0');
 await save(w,'E02_erp_connection','Report','A1:D11');
}
{
 const w=setup(['Onboarding','Lists']),s=w.worksheets.getItem('Onboarding'),l=w.worksheets.getItem('Lists');
 s.getRange('A1').values=[['HR onboarding controls']];s.getRange('A2').values=[['Four Excel extended dropdown rules; names and references must survive.']];
 s.getRange('A5:B7').values=[['Region','Cost center'],['East','CC-100'],['West','CC-200']];header(s,'A5:B5');input(s,'A6:B7');
 s.getRange('D4:E6').values=[['Input / output','Value'],['Approved requisitions',24],['Budgeted annual salary SAR',2400000]];header(s,'D4:E4');input(s,'E5');
 s.getRange('D:D').format.columnWidth=31;
 l.getRange('A1:B4').values=[['Regions','CostCenters'],['East','CC-100'],['West','CC-200'],['North','CC-300']];header(l,'A1:B1');
 await save(w,'E03_hr_validation','Onboarding','A1:F10');
}
{
 const w=setup(['Assumptions']),s=w.worksheets.getItem('Assumptions');s.getRange('A1').values=[['Sales operations pivot control']];
 s.getRange('A4:B6').values=[['Input / output','Value'],['Budget uplift',0.08],['Illustrative baseline SAR',1000000]];header(s,'A4:B4');input(s,'B5');s.getRange('B5').setNumberFormat('0%');
 s.getRange('A7').values=[['Uplifted budget SAR']];s.getRange('B7').formulas=[['=B6*(1+B5)']];s.getRange('B6:B7').setNumberFormat('#,##0');
 await save(w,'E04_pivot_control_base','Assumptions','A1:D10');
}
{
 const w=setup(['Sensitivity']),s=w.worksheets.getItem('Sensitivity');s.getRange('A1').values=[['Capital project sensitivity']];s.getRange('A2').values=[['Native two-variable What-If Data Table; fictional SAR.']];
 s.getRange('A4:B10').values=[['Assumption / output','Value'],['Contribution margin',0.25],['Annual units',10000],['Unit price SAR',120],['Annual fixed costs SAR',150000],[null,null],['Annual contribution SAR',null]];
 header(s,'A4:B4');input(s,'B5:B8');s.getRange('B5').setNumberFormat('0%');s.getRange('B6:B10').setNumberFormat('#,##0');s.getRange('B10').formulas=[['=B5*B6*B7-B8']];
 s.getRange('E4').formulas=[['=B10']];s.getRange('F4:H4').values=[[0.2,0.25,0.3]];s.getRange('E5:E7').values=[[8000],[10000],[12000]];
 s.getRange('F4:H4').setNumberFormat('0%');s.getRange('E5:H7').setNumberFormat('#,##0');header(s,'E4:H4');header(s,'E5:E7');
 s.dataTables.add('E4:H7',{rowInput:'B5',columnInput:'B6'});w.recalculate();
 await save(w,'E05_capex_sensitivity','Sensitivity','A1:I12');
}
{
 const w=setup(['Inputs','Plan','Summary']),i=w.worksheets.getItem('Inputs'),p=w.worksheets.getItem('Plan'),s=w.worksheets.getItem('Summary');
 i.getRange('A1').values=[['Supply planning inputs']];p.getRange('A1').values=[['Monthly fulfillment plan']];s.getRange('A1').values=[['Supply planning review']];
 i.getRange('A4:E8').values=[['SKU','Month','Planned receipts','Override','Demand'],['SKU-A','Jun 2026',20,null,80],['SKU-B','Jun 2026',40,0,60],['SKU-C','Jun 2026',30,null,45],['SKU-D','Jun 2026',10,null,40]];
 i.getRange('G4:I8').values=[['SKU','Initial stock','Safety stock'],['SKU-A',100,20],['SKU-B',90,10],['SKU-C',50,15],['SKU-D',60,5]];
 header(i,'A4:E4');header(i,'G4:I4');i.tables.add('A4:E8',true,'Movements');i.tables.add('G4:I8',true,'StockInputs');input(i,'C5:E8');
 i.getRange('A5:A8').dataValidation={rule:{type:'list',formula1:'StockSKUs'}};
 i.getRange('C5:E8').dataValidation={rule:{type:'whole',operator:'greaterThanOrEqual',formula1:0}};i.freezePanes.freezeRows(4);
 p.getRange('A4:I8').values=[['SKU','Month','Opening','Receipts used','Demand','Safety','Fulfilled','Unmet','Ending'],...Array.from({length:4},()=>Array(9).fill(null))];header(p,'A4:I4');
 for(let r=5;r<=8;r++)p.getRange(`A${r}:I${r}`).formulas=[[
  `=Inputs!A${r}`,`=Inputs!B${r}`,`=INDEX(Inputs!$H$5:$H$8,MATCH(A${r},Inputs!$G$5:$G$8,0))`,
  `=IF(ISBLANK(Inputs!D${r}),Inputs!C${r},Inputs!D${r})`,`=Inputs!E${r}`,
  `=INDEX(Inputs!$I$5:$I$8,MATCH(A${r},Inputs!$G$5:$G$8,0))`,`=MIN(E${r},MAX(0,C${r}+D${r}-F${r}))`,`=E${r}-G${r}`,`=C${r}+D${r}-G${r}`]];
 p.tables.add('A4:I8',true,'MonthlyPlan');p.getRange('C5:I12').setNumberFormat('#,##0');p.getRange('H5:H8').conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:'#FCE4D6'}});p.freezePanes.freezeRows(4);
 s.getRange('A4:B7').values=[['KPI','Units'],['Total fulfilled',null],['Total unmet',null],['June ending inventory',null]];header(s,'A4:B4');s.getRange('B5:B7').formulas=[['=SUM(Plan!G5:G8)'],['=SUM(Plan!H5:H8)'],['=SUM(Plan!I5:I8)']];
 s.getRange('A10:D11').values=[['Month','Fulfilled','Unmet','Ending'],['Jun 2026',null,null,null]];header(s,'A10:D10');
 s.getRange('B11:D11').formulas=[['=SUMIF(Plan!B5:B8,A11,Plan!G5:G8)'],['=SUMIF(Plan!B5:B8,A11,Plan!H5:H8)'],['=SUMIF(Plan!B5:B8,A11,Plan!I5:I8)']];
 const c=s.charts.add('line',s.getRange('A10:C11'));c.title='Fulfillment and unmet demand';c.setPosition('F4','M19');c.yAxis={numberFormatCode:'#,##0',numberFormatSourceLinked:false};s.getRange('B5:D12').setNumberFormat('#,##0');
 await save(w,'E06_supply_month_extension','Summary','A1:M20');
 await fs.writeFile(path.join(out,'movements_july.csv'),'SKU,Month,Planned receipts,Override,Demand\nSKU-C,Jul 2026,20,,30\nSKU-A,Jul 2026,50,0,45\nSKU-D,Jul 2026,25,,35\nSKU-B,Jul 2026,70,,75\n');
}
{
 const w=setup(['Forecast','PostedActuals']),s=w.worksheets.getItem('Forecast'),a=w.worksheets.getItem('PostedActuals');s.getRange('A1').values=[['Finance assumption control']];
 s.getRange('A4:B7').values=[['Input / output','Value'],['Forecast uplift',0.08],['Posted baseline SAR',null],['Forecast revenue SAR',null]];header(s,'A4:B4');input(s,'B5');s.getRange('B5').setNumberFormat('0%');
 a.getRange('A1').values=[['Posted historical revenue']];a.getRange('A4:B10').values=[['Month','Revenue SAR'],['Jan',80000],['Feb',90000],['Mar',100000],['Apr',110000],['May',120000],['Jun',130000]];header(a,'A4:B4');a.tables.add('A4:B10',true,'PostedRevenue');
 s.getRange('B6:B7').formulas=[['=SUM(PostedActuals!B5:B10)'],['=B6*(1+B5)']];s.getRange('B6:B7').setNumberFormat('#,##0');s.getRange('B5').dataValidation={rule:{type:'decimal',operator:'between',formula1:0,formula2:1}};
 await save(w,'E07_finance_control','Forecast','A1:D10');
}
