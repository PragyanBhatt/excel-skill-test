# Manual acceptance in Microsoft Excel

Use Microsoft Excel desktop and record its version. Work on disposable copies of the source and each output; do not save over the benchmark fixtures. Compare the source with both outputs. Do not treat a matching screenshot as proof that an object is native/editable.

## E01: Finance budget with approval discussion

Input: `fixtures/E01_budget_approvals.xlsx`. Outputs: `outputs/E01_openpyxl_complete.xlsx` and `outputs/E01_minimax_xml.xlsx`.

Review > Show Comments: confirm the original approval and reply still form one thread at Budget!B5. Budget!B7 should recalculate to SAR 54,000.

## E02: ERP receivables with a refresh connection

Input: `fixtures/E02_erp_connection.xlsx`. Outputs: `outputs/E02_openpyxl_complete.xlsx` and `outputs/E02_minimax_xml.xlsx`.

Data > Queries & Connections > Connections: ERPReceivablesCSV must remain present. This is a text/CSV connection, not Power Query. Repoint it to the supplied local erp_receivables.csv before testing Refresh. No corporate endpoint is contacted. Refresh execution is not part of the local automated result.

## E03: HR onboarding with extended dropdown controls

Input: `fixtures/E03_hr_validation.xlsx`. Outputs: `outputs/E03_openpyxl_complete.xlsx` and `outputs/E03_minimax_xml.xlsx`.

Click Onboarding!A6, A7, B6 and B7. All four dropdowns must remain. Test invalid values through Data > Data Validation, rather than paste, which can bypass validation.

## E04: Sales PivotTable with modern layout settings

Input: `fixtures/E04_pivot_control.xlsx`. Outputs: `outputs/E04_openpyxl_complete.xlsx` and `outputs/E04_minimax_xml.xlsx`.

Click the native PivotTable on Sheet3. PivotTable Analyze and its field list must still be available. Compare layout, including the hidden Values row and preserved default layout settings, with the fresh source. Refresh against Sheet1. This fixture embeds an unchanged Excel-authored regression PivotTable; its small sample data are not a full enterprise model.

## E05: Capital project with a native sensitivity table

Input: `fixtures/E05_capex_sensitivity.xlsx`. Outputs: `outputs/E05_openpyxl_complete.xlsx` and `outputs/E05_minimax_xml.xlsx`.

Select Sensitivity!F5:H7. The native TABLE calculation must remain. Set Calculation Options to Automatic (including data tables), recalculate, and compare the nine results with the expected matrix in expected_results.json. Then change B7 to 140 and recalculate.

## E06: Supply planning month extension with reordered SKUs

Input: `fixtures/E06_supply_month_extension.xlsx`. Outputs: `outputs/E06_openpyxl_complete.xlsx` and `outputs/E06_minimax_xml.xlsx`.

Confirm both native tables include rows 9:12, both chart series and categories include Summary row 12, both names include row 12, and validation/CF cover the appended rows. Clear Inputs!D10 (numeric zero) and recalculate: July fulfilled changes from 160 to 185, unmet from 25 to 0, and ending inventory from 90 to 115.

## E07: Ordinary finance assumption edit

Input: `fixtures/E07_finance_control.xlsx`. Outputs: `outputs/E07_openpyxl_complete.xlsx` and `outputs/E07_minimax_xml.xlsx`.

Forecast!B7 should show SAR 705,600. Change B5 to 17%; it should change to SAR 737,100. PostedActuals must remain unchanged.

For E05, expected results at price 135 are [[66000,120000,174000],[120000,187500,255000],[174000,255000,336000]]. At price 140 they are [[74000,130000,186000],[130000,200000,270000],[186000,270000,354000]]. Report Excel repair prompts, lost controls, frozen formula outputs or refresh failures as failures. Retain screenshots and the calculation/manual verdict separately from the package grader.
