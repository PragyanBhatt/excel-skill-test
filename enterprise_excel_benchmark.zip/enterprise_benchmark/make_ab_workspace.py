"""Create isolated task inputs. Does not copy reference solutions or graders.

Run from outside the harness sandbox. Install/configure the chosen skill in the
skill arm separately; this script does not claim to configure OpenCode itself.
"""
from pathlib import Path
import argparse,hashlib,json,shutil
from scenarios import SCENARIOS,prompt
ROOT=Path(__file__).resolve().parent
def main():
 p=argparse.ArgumentParser();p.add_argument('scenario',choices=SCENARIOS);p.add_argument('destination',type=Path);args=p.parse_args()
 s=SCENARIOS[args.scenario];dest=args.destination.resolve()
 if dest.exists():raise SystemExit('Destination already exists; choose a fresh directory for this run.')
 for arm in ['no_skill','with_skill']:
  d=dest/arm;(d/'fixtures').mkdir(parents=True)
  file=s['stem']+'.xlsx';shutil.copy2(ROOT/'fixtures'/file,d/'fixtures'/file)
  if args.scenario=='E06':shutil.copy2(ROOT/'fixtures'/'movements_july.csv',d/'movements_july.csv')
  if args.scenario=='E02':shutil.copy2(ROOT/'fixtures'/'erp_receivables.csv',d/'erp_receivables.csv')
  (d/'prompt.md').write_text(prompt(args.scenario));(d/'input_hash.json').write_text(json.dumps({'file':file,'sha256':hashlib.sha256((d/'fixtures'/file).read_bytes()).hexdigest()},indent=2))
 print(dest)
if __name__=='__main__':main()
