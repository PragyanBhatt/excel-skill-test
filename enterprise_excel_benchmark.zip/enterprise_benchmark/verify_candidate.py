"""Grade an arbitrary harness result structurally and through live recalculation.

Usage: python verify_candidate.py E06 /absolute/path/result.xlsx
Requires local LibreOffice. Microsoft Excel UI acceptance is still separate.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,json,math,os,shutil,subprocess
from grade import check
from scenarios import SCENARIOS
from verify_calculations import expected,make_copy,values,ROOT
def run(key,candidate):
 source=ROOT/'fixtures'/(SCENARIOS[key]['stem']+'.xlsx');structure=check(key,source,candidate);states={}
 executable=shutil.which('soffice')
 if not executable:return {'pass':False,'structural':structure,'calculation_error':'LibreOffice unavailable; Excel calculation/manual validation still required.'}
 with TemporaryDirectory(dir=ROOT/'evidence',prefix='candidate-') as temp:
  t=Path(temp);dest=t/'calculated';dest.mkdir();tmp=t/'tmp';tmp.mkdir();files=[]
  for state in ['delivered','mutated']:
   file=t/(state+'.xlsx');make_copy(candidate,key,state,file);files.append(file)
  env=os.environ.copy();env['TMPDIR']=str(tmp)
  process=subprocess.run([executable,'--headless','-env:UserInstallation='+(t/'profile').as_uri(),'--convert-to','xlsx','--outdir',str(dest),*[str(x) for x in files]],env=env,capture_output=True,text=True,timeout=60)
  for state in ['delivered','mutated']:
   want=expected(key,state);path=dest/(state+'.xlsx')
   if not path.exists():states[state]={'pass':False,'error':process.stdout+process.stderr};continue
   got=values(path,want);ok=all(got[sh][c] is not None and math.isclose(got[sh][c],v,rel_tol=1e-9,abs_tol=1e-6) for sh,cells in want.items() for c,v in cells.items())
   states[state]={'pass':ok,'expected':want,'actual':got}
 if key=='E05':return {'pass':None,'status':'requires_excel_validation','reason':'The unchanged source also fails this LibreOffice build\'s Data Table arithmetic. Use the published nine-value oracle and Microsoft Excel. Do not count this engine-specific result as agent failure.','structural':structure,'libreoffice_calculation_states':states}
 return {'pass':structure['pass'] and all(x['pass'] for x in states.values()),'scope':'Automated structural/content and LibreOffice calculation checks. Excel feature interaction remains a separate manual gate.','structural':structure,'calculation_states':states}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('scenario',choices=SCENARIOS);p.add_argument('candidate',type=Path);a=p.parse_args()
 try:r=run(a.scenario,a.candidate.resolve())
 except Exception as e:r={'pass':False,'error':str(e)}
 print(json.dumps(r,indent=2));raise SystemExit(2 if r['pass'] is None else 0 if r['pass'] else 1)
