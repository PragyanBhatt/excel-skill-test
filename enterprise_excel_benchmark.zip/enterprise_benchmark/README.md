# Enterprise Excel benchmark

Seven additional scenarios with fictional business data, shared prompts, fresh original workbooks, two executed editing workflows, independent preservation checks, numerical oracles and an OpenCode A/B protocol.

Start with `BENCHMARK_REPORT.md`. The most direct additional demonstrations are E01 (approval thread), E02 (ERP CSV connection), E03 (extended dropdowns), and E04 (modern PivotTable layout). E05–E07 provide controls and test limitations.

## Files

- `fixtures/`: seven original workbooks and two source CSVs. Match originals against `fixture_manifest.json` before each run.
- `prompts/`: one identical task prompt per scenario, usable in either harness arm.
- `outputs/`: fourteen fresh-copy workflow outputs. These are evidence/reference results, not input fixtures for another trial. Keep them outside the agent's reachable filesystem.
- `comparison_results.json`: every automated preservation gate, warnings and script timings.
- `calculation_results.json`: raw LibreOffice delivered/changed-input results on disposable copies. The E05 engine disagreement is retained, not hidden.
- `sensitivity_second_engine.json`: all three E05 files pass the independent arithmetic oracle in Artifact Tool at prices 135 and 140.
- `sensitivity_engine_control.json`: this LibreOffice build also miscalculates the unchanged E05 source. Therefore its E05 result is an engine compatibility finding, not a reliable agent-failure verdict.
- `grader_selftest.json`: seven known-good structural controls and nine deliberate corruptions detected.
- `MANUAL_CHECKS.md`, `AB_PROTOCOL.md`, `agent_run_log.csv`: enterprise acceptance steps and a blank 70-run pilot scorecard.
- `evidence/`: source previews, workflow/recalculation logs, verification copies and diagnostic evidence.
- `vendor/`: pinned MiniMax scripts and public native-feature regression components with licenses/provenance. The included scripts are unmodified. Local editors and graders are separate implementations.

## Reproduce or grade a candidate

Python 3.12 and openpyxl 3.1.5 produced the included direct workflow results. The independent structural grader itself uses Python's standard library. LibreOffice is required only for its calculation checker. Fixture rebuilding and the second sensitivity engine use `@oai/artifact-tool`; set up the documented runtime/environment or an equivalent installation.

```bash
python run_workflows.py
python test_grader.py
python grade.py E01 outputs/E01_openpyxl_complete.xlsx
python grade.py E01 outputs/E01_minimax_xml.xlsx
python verify_candidate.py E06 /absolute/path/to/harness/result.xlsx
python make_ab_workspace.py E01 /absolute/path/to/fresh_pair
```

The E01 openpyxl grading command is expected to fail because its approval thread was removed. The XML result passes the structural checks. The E05 candidate calculation command requires Microsoft Excel validation and exits 2. Structural success alone is not full enterprise acceptance.

To repeat all raw calculation checks: `python verify_calculations.py`. It deliberately exits nonzero for the retained E05 LibreOffice disagreement; inspect the JSON and baseline control before interpreting that result. `node verify_sensitivity.mjs` repeats the second-engine control.

To rebuild original fixtures, run `node build_fixtures.mjs`, then `python finalize_fixtures.py`. Rebuilding generates new native thread IDs and therefore new hashes; treat it as a new fixture version and rerun comparisons. Use the already delivered originals for the benchmark version in this package.

This is an executed workflow comparison, not a measured agent A/B or an OfficeCLI test. No agent token/cost results are fabricated. Microsoft Excel UI and external refresh checks are explicitly pending. Unknown objects must be inventoried and verified regardless of whether a skill is loaded.
