# Test the skill in your OpenCode harness

The included results compare two explicit editing workflows. They do not measure an agent's skill benefit or its token use. Use this protocol to measure that benefit without forcing the no-skill arm to fail.

1. Keep the model/version, sampling settings, tools, installed packages, hardware, timeout and task prompt identical. Start fresh sessions and fresh original fixtures. Disable auto-loading of office skills in the no-skill arm. Load the exact pinned MiniMax XLSX skill in the skill arm. Record skill text loaded and skill/tool versions.
2. Both arms may use Python, openpyxl, ZIP/XML editing and any other shared tools. A no-skill agent that independently selects XML editing must receive credit. Skills provide instructions and workflow; they do not have exclusive access to preservation techniques.
3. Keep graders, reference outputs and expected results outside the agent's reachable workspace. Make paired input directories with `python make_ab_workspace.py E01 /path/to/fresh_pair`. The generated task folders contain only the prompt, original fixture, source CSV when needed, and input hash. Configure OpenCode's filesystem scope accordingly.
4. Run at least five fresh paired trials per scenario (70 runs for seven scenarios). Alternate/randomize which arm runs first. Five is a practical pilot, not sufficient by itself for precise population estimates. Record first-attempt output before returning grader feedback. Use identical repair-feedback and retry limits in both arms; record repairs separately.
5. Blind the assessor to the arm. Run `python grade.py E01 /path/result.xlsx` for preservation/content and `python verify_candidate.py E01 /path/result.xlsx` for the combined automated gates. The latter requires LibreOffice. For E05 it returns `requires_excel_validation` (exit 2): this LibreOffice build also fails the unchanged source's Data Table arithmetic, so it is not a valid acceptance engine for that scenario. Use Microsoft Excel and the published nine-value oracle. Also perform the scenario-specific Microsoft Excel manual checks in `MANUAL_CHECKS.md`, on disposable copies. Save versioned results. A refusal or explicitly reported limitation is honest, but is not full task completion.
6. Count all input/output tokens, including skill loading, exploration, failed attempts, checks and repairs. Preserve provider cache-read/cache-write categories and use billed cost to account for their prices. Record elapsed time from request to accepted delivery and assessor repair minutes. Do not substitute the included script execution seconds for agent latency.

Use these metrics:

- First-attempt acceptance = outputs passing all required gates before feedback / runs.
- Accepted delivery after repairs = completed accepted outputs / runs.
- Cost per accepted delivery = total billed cost across all attempts and repairs / accepted deliveries.
- Tokens per accepted delivery = total billed token usage across all attempts and repairs / accepted deliveries; also retain the provider token categories.
- Time per accepted delivery = total task elapsed time across all runs / accepted deliveries. For interactive experience, also report the median and p90 time to acceptance among successful runs.
- Manual review/repair time = total assessor minutes per run and per accepted output.

When there are zero accepted deliveries, cost/time per accepted delivery is undefined; report zero acceptance and total spend. Do not divide by zero or report zero cost. Compare results per scenario before pooling. Weight a pooled result by your actual enterprise task mix; these deliberately selected preservation stress tests are not a representative workload sample.

The strongest additional ablation is a third arm with no specialized skill but a concise generic instruction to inventory native objects and preserve unknown XML parts. If it matches the full skill, the benefit may come from a few reusable instructions rather than the entire skill package.

OfficeCLI requires a separate experiment with its actual installed, version-pinned capabilities. Add a tool-only arm and a tool-plus-skill arm if you need to separate tool benefit from skill instructions. This package does not test OfficeCLI or assert that it preserves every Excel feature.

Suggested decision rule: use the skill when its verified acceptance or repair savings reduces cost/time per accepted delivery, or protects an object essential to that task. Permit the simpler workflow when it passes the same acceptance gates with lower cost. Publish both wins and controls.
