"""Numerical oracle + LibreOffice recalculation of disposable copies.

Final files remain untouched. Verifies delivered and changed-input states for
both workflows. Does not claim Excel UI, query refresh or VBA execution.
"""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,math,os,shutil,subprocess,time
from package_reader import Package,NS
from run_workflows import set_cell,invalidate_formula_caches,request_recalc,cell_match
from scenarios import SCENARIOS
ROOT=Path(__file__).resolve().parent;EV=ROOT/'evidence';IN=EV/'recalc_inputs';OUT=EV/'recalculated';TMP=EV/'tmp'
for p in [IN,OUT,TMP]:p.mkdir(exist_ok=True)
def expected(key,state):
 changed=state=='mutated'
 if key=='E01':return {'Budget':{'B5':150000 if changed else 135000,'B6':81000,'B7':69000 if changed else 54000}}
 if key=='E02':return {'Report':{'B5':0.05 if changed else 0.03,'B6':390000,'B7':190000,'B8':9500 if changed else 5700}}
 if key=='E03':return {'Onboarding':{'E5':36 if changed else 30,'E6':2400000}}
 if key=='E04':return {'Assumptions':{'B5':0.17 if changed else 0.12,'B7':1170000 if changed else 1120000}}
 if key=='E05':
  price=140 if changed else 135;values={'B7':price,'B10':0.25*10000*price-150000}
  for r,units in enumerate([8000,10000,12000],5):
   for c,margin in zip('FGH',[0.2,0.25,0.3]):values[f'{c}{r}']=units*price*margin-150000
  return {'Sensitivity':values}
 if key=='E06':
  july=[[35,20,30,15,30,0,25],[40,50 if changed else 0,45,20,45 if changed else 20,0 if changed else 25,45 if changed else 20],[30,25,35,5,35,0,20],[30,70,75,10,75,0,25]]
  june=[[100,20,80,20,80,0,40],[90,0,60,10,60,0,30],[50,30,45,15,45,0,35],[60,10,40,5,40,0,30]]
  plan={f'{c}{r}':v for r,row in enumerate(june+july,5) for c,v in zip('CDEFGHI',row)}
  return {'Plan':plan,'Summary':{'B5':410 if changed else 385,'B6':0 if changed else 25,'B7':115 if changed else 90,'B11':225,'C11':0,'D11':135,'B12':185 if changed else 160,'C12':0 if changed else 25,'D12':115 if changed else 90}}
 if key=='E07':return {'Forecast':{'B5':0.17 if changed else 0.12,'B6':630000,'B7':737100 if changed else 705600}}
MUTATIONS={'E01':('Budget','B5',150000),'E02':('Report','B5',0.05),'E03':('Onboarding','E5',36),'E04':('Assumptions','B5',0.17),'E05':('Sensitivity','B7',140),'E06':('Inputs','D10',None),'E07':('Forecast','B5',0.17)}
def make_copy(src,key,state,dest):
 pkg=Package(src);sheet_paths={n:p for n,_,p in pkg.sheets};mut=MUTATIONS[key]
 with ZipFile(src) as zi,ZipFile(dest,'w',ZIP_DEFLATED) as zo:
  for n in zi.namelist():
   data=zi.read(n)
   if n.startswith('xl/worksheets/') and n.endswith('.xml'):
    text=data.decode();text=invalidate_formula_caches(text)
    if key=='E05' and n==sheet_paths['Sensitivity']:
     # TABLE child results are caches even though only the anchor carries <f>.
     import re
     for r in range(5,8):
      for c in 'FGH':
       m=cell_match(text,f'{c}{r}');new=re.sub(r'<(?:\w+:)?v\b[^>]*(?:/>|>.*?</(?:\w+:)?v>)','',m[0],flags=re.S);text=text[:m.start()]+new+text[m.end():]
    if state=='mutated' and n==sheet_paths[mut[0]]:text=set_cell(text,mut[1],mut[2])
    data=text.encode()
   elif n=='xl/workbook.xml':data=request_recalc(data.decode()).encode()
   zo.writestr(n,data)
def values(path,wanted):
 pkg=Package(path);actual={}
 for sheet,cells in wanted.items():
  tree=pkg.sheet_trees[sheet];mapping={c.get('r'):c for c in tree.findall('.//s:c',NS)};actual[sheet]={}
  for address in cells:
   c=mapping.get(address);v=c.find('s:v',NS) if c is not None else None
   try:actual[sheet][address]=float(v.text)
   except (TypeError,AttributeError,ValueError):actual[sheet][address]=None
 return actual
def run():
 executable=shutil.which('soffice')
 if not executable:raise SystemExit('LibreOffice required for this calculation check; structural grader needs only Python.')
 env=os.environ.copy();env['TMPDIR']=str(TMP);profile=(EV/'lo_profile').as_uri()
 engine=subprocess.run([executable,'--version'],env=env,capture_output=True,text=True,timeout=15).stdout.strip()
 results={'scope':'Live calculations only, on disposable copies. Not Excel UI or external refresh acceptance.','engine':engine,'states':{},'pass':True}
 originals={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'outputs').glob('*.xlsx')}
 for key,s in SCENARIOS.items():
  inputs=[]
  for arm in ['openpyxl_complete','minimax_xml']:
   src=ROOT/'outputs'/(key+'_'+arm+'.xlsx')
   for state in ['delivered','mutated']:
    dest=IN/(key+'_'+arm+'_'+state+'.xlsx');make_copy(src,key,state,dest);inputs.append(dest)
    old=OUT/dest.name
    if old.exists():old.unlink()
  cmd=[executable,'--headless','-env:UserInstallation='+profile,'--convert-to','xlsx','--outdir',str(OUT),*[str(x) for x in inputs]]
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=60);(EV/(key+'_recalc.log')).write_text(p.stdout+p.stderr)
  for inp in inputs:
   state='mutated' if '_mutated' in inp.stem else 'delivered';want=expected(key,state);recalc=OUT/inp.name
   if not recalc.exists():results['states'][inp.stem]={'pass':False,'error':p.stdout+p.stderr};results['pass']=False;continue
   got=values(recalc,want);ok=all(got[sh][c] is not None and math.isclose(got[sh][c],v,rel_tol=1e-9,abs_tol=1e-6) for sh,cells in want.items() for c,v in cells.items())
   results['states'][inp.stem]={'pass':ok,'expected':want,'actual':got};results['pass'] &= ok
  print(key,{inp.stem:results['states'][inp.stem]['pass'] for inp in inputs},flush=True)
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==digest for p,digest in originals.items())
 results['delivery_files_unchanged']=True
 results['delivery_sha256']={p.name:digest for p,digest in originals.items()}
 (ROOT/'calculation_results.json').write_text(json.dumps(results,indent=2));(ROOT/'expected_results.json').write_text(json.dumps({k:{st:expected(k,st) for st in ['delivered','mutated']} for k in SCENARIOS},indent=2))
 if not results['pass']:raise SystemExit('One or more live-calculation states failed; see calculation_results.json.')
if __name__=='__main__':run()
