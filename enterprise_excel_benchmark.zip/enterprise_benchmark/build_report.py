"""Produce the report and scorecards from measured results, not invented runs."""
from pathlib import Path
import csv,json
from scenarios import SCENARIOS
ROOT=Path(__file__).resolve().parent
def main():
 results=json.loads((ROOT/'comparison_results.json').read_text());calcs=json.loads((ROOT/'calculation_results.json').read_text());second=json.loads((ROOT/'sensitivity_second_engine.json').read_text())
 rows=[]
 meanings={
  'E01':('Budget approval record','Thread and reply removed; legacy fallback text is not a preserved conversation.'),
  'E02':('ERP reporting connection','Connection/query parts and package bindings removed; current cells still calculate.'),
  'E03':('HR entry controls','All four x14 dropdown rules removed; library emits a warning.'),
  'E04':('Sales reporting layout','Core PivotTable/cache retained; modern layout extensions, including hideValuesRow, removed.'),
  'E05':('Capex sensitivity','Both preserve the native What-If Data Table. Both pass the second-engine oracle; Excel acceptance pending.'),
  'E06':('Supply planning rollover','Both correctly extend tables, names, formulas, chart bindings, validation and CF, with reordered SKUs and zero overrides.'),
  'E07':('Finance driver edit','Both preserve the workbook and live formulas.'),
 }
 for key,s in SCENARIOS.items():
  w=results['scenarios'][key]['workflows'];rows.append((key,meanings[key][0],w['openpyxl_complete']['pass'],w['minimax_xml']['pass'],meanings[key][1]))
 direct=sum(r[2] for r in rows);skill=sum(r[3] for r in rows);silent=sum(not results['scenarios'][r[0]]['workflows']['openpyxl_complete']['warnings'] for r in rows if not r[2])
 native_pass=sum(x['pass'] for x in calcs['states'].values());native_total=len(calcs['states'])
 table='| Scenario | Direct openpyxl | MiniMax XML workflow | Measured result |\n|---|---|---|---|\n'+''.join(f'| {key}: {label} | {"Pass" if a else "Fail"} | {"Pass" if b else "Fail"} | {detail} |\n' for key,label,a,b,detail in rows)
 report=f'''# Enterprise Excel preservation benchmark

Seven additional enterprise scenarios were built and tested on fresh copies. Direct openpyxl passed all automated preservation gates in **{direct}/7** scenarios; the MiniMax skill's prescribed XML editing workflow passed in **{skill}/7**. These are measured workflow outcomes, not proof that every agent without skills will fail or that every skill-assisted agent will succeed.

{table}
## What this establishes

The four failing direct edits all made the requested input change. Their enterprise features were lost during save. Three of the four loss cases were silent: openpyxl emitted no warning for approval threads, the ERP connection or modern PivotTable layout. The HR validation case emitted an explicit unsupported-extension warning. A workbook opening successfully and showing correct totals would not detect these losses.

The XML workflow retained those objects while changing the requested inputs. It uses MiniMax's unmodified unpack/pack scripts pinned to commit `60aaae52bb2af8162732751a4332f62a5fef518b`, with a local XML editor implementing the tasks. This tests an editing strategy prescribed by the skill; it does not run MiniMax or another model as an agent.

The three controls are equally useful. openpyxl can preserve this native sensitivity table and perform the complete month extension when its dependencies are explicitly updated. Neither ordinary formulas nor row extension inherently requires a specialized skill. The month-extension success covers SKU-based carry-forward despite reordered rows, live fulfillment rules, native tables, named ranges, chart category/series expansion, validation, conditional formatting and blank/zero receipt behavior.

## Verification and limits

The preservation grader is independent of both editors and uses only Python's standard library. It checks values/formula text, resolved styles, native object definitions, bindings, coverage and geometry. It ignores harmless XML prefixes, indentation and equivalent default-valued serialization. Its self-test accepts seven known-good workbooks and detects nine deliberate corruptions, including removed objects, stale table coverage, a wrong opening reference and a cleared zero override.

On disposable copies, LibreOffice recalculation passed **{native_pass}/{native_total}** delivered/changed-input states. All six non-sensitivity scenarios passed in both workflows. These checks include historical June results, July-only inventory, later changes to the uplift/rate, and clearing a July numeric-zero override. Final delivery files were not changed by recalculation.

The sensitivity grid requires a qualified reading: the openpyxl output passes LibreOffice; the XML output gives incorrect TABLE values in that engine. The unchanged original fixture shows the same LibreOffice disagreement. All three files—source and both outputs—pass all nine sensitivity results at both test prices in Artifact Tool, checked against an independent arithmetic oracle. Therefore this is recorded as an engine compatibility issue needing Microsoft Excel validation, rather than an agent-failure verdict. The raw failing evidence remains included.

Native Microsoft Excel interaction, connection refresh and visual layout behavior have not been executed here. Those are explicit final gates in `MANUAL_CHECKS.md`. The ERP case is an offline text/CSV connection, not Power Query, a live SAP connection or the Excel Data Model. The PivotTable component is a public Excel-authored regression fixture with a small data sample, supplemented by independent enterprise assumptions. No OfficeCLI execution or OpenCode token measurements are claimed.

## Use the prompts in your harness

The package contains the original workbook, source CSV where relevant, full shared prompt, both workflow outputs, grader and manual checks for each scenario. Start with **E01–E04** to demonstrate preservation risks, and retain **E05–E07** as controls. Use the original fixtures, never a previous test's output.

For example, E01 asks the agent to change Budget!B5 to SAR 135,000 while retaining the native approval conversation and reply. Review > Show Comments provides a manual check; the package checker detects thread loss independently. E02 changes a reserve rate while preserving the refresh infrastructure. E03 changes approved headcount while keeping four dropdown controls. E04 changes an independent sales assumption while keeping the pivot's modern layout options.

For a causal skill comparison, follow `AB_PROTOCOL.md`: same model/settings/tools and prompt, separate fresh sessions, five paired runs per scenario as a pilot, blinded grading, equal repair limits and full token/cost accounting. Both arms must be allowed to choose XML editing. A no-skill agent that chooses the same preserving strategy deserves a pass. Keep reference outputs and graders outside the agent's reachable workspace.

`agent_run_log.csv` is an empty 70-run scorecard. It has no fabricated token, duration or acceptance entries. Measure first-attempt acceptance, failures/repairs and **total cost/time per accepted delivery**, including failed attempts and skill-loading overhead. The observed preservation difference is {skill/7*100-direct/7*100:.1f} percentage points on this deliberately selected suite; it is not an enterprise-wide failure-rate estimate.

## Decision supported by this evidence

Use a preservation-aware workflow for workbooks containing native comments/replies, refresh connections, extended validation or modern PivotTable metadata. The useful skill content is the inventory of workbook objects, choice of a preserving editor and independent object/calculation verification. For simpler models that pass the same gates, compare the skill's overhead against the direct workflow. A skill reading alone does not ensure preservation; a compatible editor and verification must follow it.
'''
 (ROOT/'BENCHMARK_REPORT.md').write_text(report)
 manual='# Manual acceptance in Microsoft Excel\n\nUse Microsoft Excel desktop and record its version. Work on disposable copies of the source and each output; do not save over the benchmark fixtures. Compare the source with both outputs. Do not treat a matching screenshot as proof that an object is native/editable.\n\n'
 for key,s in SCENARIOS.items():manual+=f"## {key}: {s['title']}\n\nInput: `fixtures/{s['stem']}.xlsx`. Outputs: `outputs/{key}_openpyxl_complete.xlsx` and `outputs/{key}_minimax_xml.xlsx`.\n\n{s['manual']}\n\n"
 manual+='For E05, expected results at price 135 are [[66000,120000,174000],[120000,187500,255000],[174000,255000,336000]]. At price 140 they are [[74000,130000,186000],[130000,200000,270000],[186000,270000,354000]]. Report Excel repair prompts, lost controls, frozen formula outputs or refresh failures as failures. Retain screenshots and the calculation/manual verdict separately from the package grader.\n'
 (ROOT/'MANUAL_CHECKS.md').write_text(manual)
 with (ROOT/'workflow_summary.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['scenario','enterprise_case','openpyxl_preservation_pass','minimax_xml_preservation_pass','observed_result']);w.writerows(rows)
 fields=['scenario','pair_id','arm','model_version','skill_version','tool_versions','input_sha256','provider_input_tokens','provider_output_tokens','provider_cache_read_tokens','provider_cache_write_tokens','skill_tokens_loaded','billed_cost','elapsed_seconds','first_attempt_structural_pass','calculation_pass','excel_manual_pass','first_attempt_accepted','repair_attempts','assessor_repair_minutes','final_accepted','notes']
 with (ROOT/'agent_run_log.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
  for key in SCENARIOS:
   for pair in range(1,6):
    for arm in ['no_skill','with_skill']:w.writerow({'scenario':key,'pair_id':pair,'arm':arm})
 print(json.dumps({'structural_pass_scenarios':{'openpyxl':direct,'minimax_xml':skill},'silent_loss_cases':silent,'raw_native_states':f'{native_pass}/{native_total}','second_sensitivity_engine_pass':second['pass'],'scorecard_rows':70}))
if __name__=='__main__':main()
