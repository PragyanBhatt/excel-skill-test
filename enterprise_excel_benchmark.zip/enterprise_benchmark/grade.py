"""Independent stdlib OOXML grader. No editing-library imports or expected output file.

Usage: python grade.py E01 candidate.xlsx [--source source.xlsx]
Returns nonzero unless all automated structural/content gates pass. Native Excel
interaction must be recorded separately; this checker cannot execute Excel UI.
"""
from pathlib import Path
from collections import Counter
import copy,json,re,sys,xml.etree.ElementTree as E
from package_reader import Package,canonical,NS,S,R,X14
from scenarios import SCENARIOS
ROOT=Path(__file__).resolve().parent
def number(value):
 try:return float(value)
 except (ValueError,TypeError):return value
def equivalent(a,b):
 if a is None or b is None:return a==b
 if a[0]=='n' and b[0]=='n':return number(a[1])==number(b[1])
 return a==b
def names(pkg):
 return {n.get('name'):n.text for n in pkg.xml['xl/workbook.xml'].findall('s:definedNames/s:definedName',NS)}
def parts(pkg,condition):
 return sorted((canonical(t) for p,t in pkg.xml.items() if condition(p,t)),key=str)
def links(pkg,kind):
 out=[]
 for p,t in pkg.xml.items():
  if not p.endswith('.rels'):continue
  owner=p.replace('/_rels/','/').removesuffix('.rels')
  for rel in t:
   if rel.get('Type','').endswith('/'+kind):
    target=Package.target(owner,rel.get('Target'));out.append((owner,kind,target in pkg.parts))
 return sorted(out)
def normalize_pivot(t):
 """Normalize only documented defaults used by this fixture's pivot items."""
 if t is None:return None
 t=copy.deepcopy(t)
 defaults_by_tag={'item':{'t':'data','sd':'1'},'i':{'i':'0','r':'0','t':'data'},'x':{'v':'0'},'dataField':{'showDataAs':'normal','subtotal':'sum'}}
 for n in t.iter():
  defaults=defaults_by_tag.get(n.tag.split('}')[-1],{})
  for k in list(n.attrib):
   if k in defaults and n.get(k)==defaults[k]:n.attrib.pop(k)
 return canonical(t)
def check(key,source,candidate):
 s=SCENARIOS[key];a,b=Package(source),Package(candidate);checks=[]
 def record(label,ok,detail=None):checks.append({'requirement':label,'passed':bool(ok),'detail':detail})
 ca,cb=a.cell_map(),b.cell_map();edits=set()
 if key!='E06':
  target=(s['sheet'],s['cell']);edits.add(target);record('Requested input is correct',equivalent(cb.get(target),('n',str(s['value']))))
 else:
  edits={('Summary',x) for x in ['B5','B6','A7','B7','A12','B12','C12','D12']}
  for sh,last in [('Inputs','E'),('Plan','I')]:
   for r in range(9,13):edits.update((sh,chr(c)+str(r)) for c in range(65,ord(last)+1))
 if key=='E05':edits.update(('Sensitivity',chr(c)+str(r)) for c in range(70,73) for r in range(5,8))
 changed=[]
 for k in set(ca)|set(cb):
  if k in edits:continue
  x,y=ca.get(k),cb.get(k)
  # An absent unformatted blank cell and a serialized empty cell are equivalent.
  if x in {None,('n',None)} and y in {None,('n',None)}:continue
  if not equivalent(x,y):changed.append(f'{k[0]}!{k[1]}')
 record('Unrelated values and live formula text are preserved',not changed,sorted(changed)[:20])
 record('Sheet names/order/visibility are preserved',[(n,v) for n,v,_ in a.sheets]==[(n,v) for n,v,_ in b.sheets])
 sa,sb=a.styles(),b.styles();new_cells=set()
 if key=='E06':
  for sh,cols in [('Inputs','ABCDE'),('Plan','ABCDEFGHI')]:new_cells.update((sh,f'{c}{r}') for r in range(9,13) for c in cols)
  new_cells.update(('Summary',f'{c}12') for c in 'ABCD')
 style_changes=[f'{k[0]}!{k[1]}' for k,v in sa.items() if k not in new_cells and sb.get(k,b.resolved_styles[0])!=v]
 record('Existing cell formats are preserved',not style_changes,style_changes[:20])
 for tag,label in [('sheetViews','Frozen panes and views'),('mergeCells','Merged cells')]:record(label+' are preserved',a.feature(tag)==b.feature(tag))
 def columns(pkg):
  result={}
  for sheet,tree in pkg.sheet_trees.items():
   result[sheet]=[]
   for col in tree.findall('s:cols/s:col',NS):
    attr=dict(col.attrib);style=int(attr.pop('style','0'));attr.pop('hidden',None) if attr.get('hidden') in {'0','false'} else None
    result[sheet].append((tuple(sorted(attr.items())),pkg.resolved_styles[style]))
  return result
 record('Column geometry and resolved column styles are preserved',columns(a)==columns(b))
 if key!='E06':
  record('Native tables are preserved',a.tables()==b.tables())
  record('Defined names are preserved',names(a)==names(b))
  for tag in ['dataValidations','conditionalFormatting']:record(tag+' are preserved',a.feature(tag)==b.feature(tag))
  record('Existing editable chart content/geometry are preserved',a.chart_content()==b.chart_content() and a.chart_geometry()==b.chart_geometry())
 errors=[(n,c.get('r')) for n,t in b.sheet_trees.items() for c in t.findall('.//s:c',NS) if c.get('t')=='e'];record('No cached error values',not errors,errors)
 feature=s['feature']
 if feature=='threads':
  choose=lambda p,t: 'threadedcomment' in p.lower() or '/persons/' in p.lower()
  original=parts(a,choose);actual=parts(b,choose)
  record('Native comment thread, reply, authors and IDs are preserved',bool(original) and original==actual,{'source_parts':sum(choose(p,t) for p,t in a.xml.items()),'output_parts':sum(choose(p,t) for p,t in b.xml.items())})
  record('Thread and person package bindings remain',links(a,'threadedComment')==links(b,'threadedComment') and links(a,'person')==links(b,'person'))
 if feature=='connection':
  choose=lambda p,t:p=='xl/connections.xml' or '/queryTables/' in p
  record('ERP connection and query-table definitions remain intact',parts(a,choose)==parts(b,choose) and bool(parts(b,choose)))
  record('Connection/query/table relationships remain valid',links(a,'connections')==links(b,'connections') and links(a,'queryTable')==links(b,'queryTable'))
 if feature=='extended_validation':
  choose=lambda pkg:tuple(canonical(n) for t in pkg.sheet_trees.values() for n in t.findall('.//{'+X14+'}dataValidations'))
  rules=lambda pkg:sum(len(t.findall('.//{'+X14+'}dataValidation')) for t in pkg.sheet_trees.values())
  record('All four extended dropdown controls and references remain',rules(a)==rules(b)==4 and choose(a)==choose(b),{'before':rules(a),'after':rules(b)})
 if feature=='pivot':
  def signature(p):
   tables=[];caches=[];records=[]
   for path,t in p.xml.items():
    if t.tag=='{'+S+'}pivotTableDefinition':
     fields=[]
     for field in t.findall('s:pivotFields/s:pivotField',NS):fields.append((field.get('axis'),field.get('dataField','0'),field.get('showAll','1'),normalize_pivot(field.find('s:items',NS))))
     selected=[]
     for tag in ['location','rowFields','rowItems','colFields','colItems','pageFields','dataFields','pivotTableStyleInfo']:
      selected.append(normalize_pivot(t.find('s:'+tag,NS)))
     tables.append((t.get('name'),t.get('cacheId'),tuple(fields),tuple(selected)))
    elif t.tag=='{'+S+'}pivotCacheDefinition':
     fields=[]
     for field in t.findall('s:cacheFields/s:cacheField',NS):
      shared=field.find('s:sharedItems',NS);fields.append((field.get('name'),tuple(canonical(x) for x in shared) if shared is not None else ()))
     caches.append((t.get('recordCount'),canonical(t.find('s:cacheSource',NS)),tuple(fields)))
    elif t.tag=='{'+S+'}pivotCacheRecords':records.append((t.get('count'),tuple(canonical(x) for x in t)))
   return tables,caches,records
  record('Core native PivotTable/source/cache/records remain',signature(a)==signature(b) and bool(signature(b)[0]))
  def modern(p):return sorted((canonical(n) for path,t in p.xml.items() if '/pivotTables/' in path or '/pivotCache/' in path for n in t.findall('s:extLst',NS)),key=str)
  record('Modern PivotTable layout extensions remain intact',modern(a)==modern(b) and bool(modern(b)))
  record('PivotTable and cache relationships remain valid',all(links(a,k)==links(b,k) for k in ['pivotTable','pivotCacheDefinition','pivotCacheRecords']))
 if feature=='data_table':
  def dt(p):return [(n,c.get('r'),canonical(c.find('s:f',NS))) for n,t in p.sheet_trees.items() for c in t.findall('.//s:c',NS) if c.find('s:f',NS) is not None and c.find('s:f',NS).get('t')=='dataTable']
  record('Native two-input Data Table and input bindings remain',dt(a)==dt(b) and len(dt(b))==1,dt(b))
 if feature=='extension':
  rows=[['SKU-C','Jul 2026',20,None,30],['SKU-A','Jul 2026',50,0,45],['SKU-D','Jul 2026',25,None,35],['SKU-B','Jul 2026',70,None,75]]
  ok=True
  for r,row in enumerate(rows,9):
   for col,v in zip('ABCDE',row):
    got=cb.get(('Inputs',f'{col}{r}'));want=('text',v) if isinstance(v,str) else ('n',None if v is None else str(v));ok &= equivalent(got,want) or (v is None and got is None)
  record('July source records preserve order and blank/zero semantics',ok)
  openings=[('Plan',f'C{r}') for r in range(9,13)]
  # Require lookup by SKU against June, allowing INDEX/MATCH, XLOOKUP or SUMIF.
  open_ok=True
  for k in openings:
   val=cb.get(k);f=val[1][2].upper().replace('$','').replace('PLAN!','').replace("'PLAN'!",'') if val and val[0]=='formula' else ''
   open_ok &= ('I5:I8' in f and f'A{k[1][1:]}' in f and ('MATCH(' in f or 'XLOOKUP(' in f or 'SUMIF(' in f))
  record('July opening formulas match SKU to June ending',open_ok)
  all_live=all(cb.get(('Plan',f'{c}{r}'),('',))[0]=='formula' for r in range(9,13) for c in 'CDEFGHI')
  record('All July Plan calculation cells are live formulas',all_live)
  tables=[t for t in b.xml.values() if t.tag=='{'+S+'}table'];refs={t.get('name'):t.get('ref') for t in tables}
  record('Both native planning tables include July',refs.get('Movements')=='A4:E12' and refs.get('MonthlyPlan')=='A4:I12' and refs.get('StockInputs')=='G4:I8',refs)
  expected_names={'StockSKUs':'Inputs!$G$5:$G$8','ReportingMonths':'Summary!$A$11:$A$12','FulfilledUnits':'Summary!$B$11:$B$12'};record('All defined names have the requested coverage',names(b)==expected_names,names(b))
  chart_a,chart_b=a.chart_content(),b.chart_content();binds=chart_b[0][1] if len(chart_b)==1 else []
  wanted=['Summary!$A$11:$A$12','Summary!$B$11:$B$12','Summary!$C$11:$C$12'];clean=[x.replace("'",'') for x in binds]
  record('One existing chart has categories and both July series',len(chart_b)==1 and all(x in clean for x in wanted),list(binds))
  record('Chart title/styling/geometry are preserved',len(chart_b)==1 and chart_a[0][0]==chart_b[0][0] and chart_a[0][2:]==chart_b[0][2:] and a.chart_geometry()==b.chart_geometry())
  dvranges={n.get('sqref') for n in b.sheet_trees['Inputs'].findall('.//s:dataValidation',NS)}
  record('SKU and quantity validation cover July','A5:A12' in dvranges and 'C5:E12' in dvranges,sorted(dvranges))
  record('Unmet-demand conditional formatting covers July',any(n.get('sqref')=='H5:H12' for n in b.sheet_trees['Plan'].findall('s:conditionalFormatting',NS)))
  label=cb.get(('Summary','A7'));record('July ending label is correct',label==('text','July ending inventory'))
  record('July totals and overall totals remain formulas',all(cb.get(('Summary',c),('',))[0]=='formula' for c in ['B5','B6','B7','B12','C12','D12']))
  format_ok=all(sb.get((sh,f'{c}{r}'))==sa.get((sh,f'{c}5')) for sh,cols in [('Inputs','ABCDE'),('Plan','ABCDEFGHI')] for r in range(9,13) for c in cols)
  record('Appended cells use corresponding established formats',format_ok)
 return {'scenario':key,'pass':all(x['passed'] for x in checks),'passed_checks':sum(x['passed'] for x in checks),'total_checks':len(checks),'checks':checks}
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('scenario',choices=SCENARIOS);p.add_argument('candidate',type=Path);p.add_argument('--source',type=Path);arg=p.parse_args()
 source=arg.source or ROOT/'fixtures'/(SCENARIOS[arg.scenario]['stem']+'.xlsx')
 try:result=check(arg.scenario,source,arg.candidate)
 except Exception as e:result={'scenario':arg.scenario,'pass':False,'error':str(e)}
 print(json.dumps(result,indent=2));sys.exit(0 if result['pass'] else 1)
