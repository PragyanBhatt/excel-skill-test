#!/usr/bin/env python3
"""Read-only, standard-library XLSX grader. Does NOT calculate formulas.
Shared OOXML reader for the M1 and D50K evaluators.
Recalculate a disposable copy in your declared spreadsheet engine first.
Keep this directory outside the tested agent's accessible workspace.
"""
import argparse
import copy
import json
import math
import posixpath
import re
import sys
import zipfile
from datetime import date
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'p': 'http://schemas.openxmlformats.org/package/2006/relationships',
      'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart'}
S = '{'+NS['s']+'}'
R = '{'+NS['r']+'}'


def canon(el, strip_caches=False):
    if el is None:
        return None
    if strip_caches and el.tag.split('}')[-1] in {'numCache', 'strCache', 'multiLvlStrCache'}:
        return None
    return (el.tag, tuple(sorted(el.attrib.items())), (el.text or '').strip(),
            tuple(v for c in el if (v := canon(c, strip_caches)) is not None))


def colnum(col):
    n = 0
    for c in col:
        n = n * 26 + ord(c) - 64
    return n


def colname(n):
    result = ''
    while n:
        n, r = divmod(n-1, 26)
        result = chr(65+r)+result
    return result


def addr_parts(a):
    m = re.fullmatch(r'([A-Z]+)(\d+)', a)
    return colnum(m[1]), int(m[2])


def translated_formula(formula, origin, destination):
    oc, orow = addr_parts(origin)
    dc, drow = addr_parts(destination)
    def sub(m):
        dollars_c, col, dollars_r, row = m.groups()
        ncol = colnum(col) + (0 if dollars_c else dc-oc)
        nrow = int(row) + (0 if dollars_r else drow-orow)
        if ncol < 1 or nrow < 1:
            return '#REF!'
        return f'{dollars_c}{colname(ncol)}{dollars_r}{nrow}'
    # Protect quoted string literals from A1-reference translation.
    return ''.join(part if i % 2 else re.sub(r'(?<![A-Za-z0-9_])([$]?)([A-Z]{1,3})([$]?)(\d+)(?![A-Za-z0-9_])', sub, part)
                   for i, part in enumerate(re.split(r'("(?:[^"]|"")*")', formula)))


def serial(dt):
    return (date.fromisoformat(dt)-date(1899,12,30)).days


class Xlsx:
    def __init__(self, path):
        self.path = Path(path)
        self.zip = zipfile.ZipFile(self.path)
        corrupt = self.zip.testzip()
        if corrupt:
            raise ValueError(f'Corrupt ZIP member: {corrupt}')
        self.parts = set(self.zip.namelist())
        self.xml = {p: ET.fromstring(self.zip.read(p)) for p in self.parts if p.endswith('.xml') or p.endswith('.rels')}
        self.shared = []
        if 'xl/sharedStrings.xml' in self.xml:
            self.shared = [''.join(t.text or '' for t in si.iter(S+'t')) for si in self.xml['xl/sharedStrings.xml']]
        self.sheets, self.cells = {}, {}
        rels = self.relationships('xl/workbook.xml')
        wb = self.xml['xl/workbook.xml']
        self.sheet_info = []
        for entry in wb.find('s:sheets',NS):
            name = entry.get('name')
            part = rels[entry.get(R+'id')]
            self.sheets[name] = part
            self.sheet_info.append((name, entry.get('state','visible')))
            grid, anchors = {}, {}
            for c in self.xml[part].findall('.//s:sheetData/s:row/s:c', NS):
                address, kind = c.get('r'), c.get('t')
                v, f = c.find('s:v',NS), c.find('s:f',NS)
                value = None if v is None or v.text is None else v.text
                if kind == 's' and value is not None:
                    value = self.shared[int(value)]
                elif kind == 'inlineStr':
                    value = ''.join(t.text or '' for t in c.findall('.//s:t',NS))
                elif kind == 'd' and value is not None:
                    value = serial(value[:10])
                elif kind not in {'str','e','d'} and value is not None:
                    value = float(value)
                    if value.is_integer():
                        value = int(value)
                formula = None if f is None else (f.text or '')
                if f is not None and f.get('t') == 'shared' and formula:
                    anchors[f.get('si')] = (address, formula)
                grid[address] = {'value': value, 'formula': formula, 'kind':kind,
                                 'style':int(c.get('s','0')), 'shared':None if f is None else f.get('si')}
            for address,c in grid.items():
                if c['formula'] == '' and c['shared'] in anchors:
                    origin, expression = anchors[c['shared']]
                    c['formula'] = translated_formula(expression,origin,address)
            self.cells[name] = grid
        self.names = {n.get('name'): canon(n) for n in wb.findall('s:definedNames/s:definedName',NS)}

    def relationships(self, part):
        directory, filename = posixpath.split(part)
        relpath = posixpath.join(directory,'_rels',filename+'.rels')
        result = {}
        for rel in self.xml.get(relpath, []):
            if rel.get('TargetMode') == 'External':
                continue
            target = rel.get('Target')
            result[rel.get('Id')] = target.lstrip('/') if target.startswith('/') else posixpath.normpath(posixpath.join(directory,target))
        return result

    def get(self, sheet, address):
        return self.cells.get(sheet,{}).get(address, {'value':None,'formula':None,'kind':None,'style':0})

    def rows(self, sheet, start, count, width):
        return [[self.get(sheet,f'{colname(c)}{r}')['value'] for c in range(1,width+1)]
                for r in range(start,start+count)]

    def style(self, index):
        styles = self.xml.get('xl/styles.xml')
        if styles is None:
            return None
        xfs = styles.find('s:cellXfs',NS)
        xf = xfs[index]
        attrs = dict(xf.attrib)
        resolved = []
        for key, group in [('fontId','fonts'),('fillId','fills'),('borderId','borders')]:
            idx = int(attrs.pop(key,'0'))
            pool = styles.find('s:'+group,NS)
            resolved.append(canon(pool[idx]) if pool is not None else None)
        nf = attrs.pop('numFmtId','0')
        custom = {n.get('numFmtId'):n.get('formatCode') for n in styles.findall('s:numFmts/s:numFmt',NS)}
        resolved.append(custom.get(nf,'builtin:'+nf))
        attrs.pop('xfId',None)
        return (tuple(sorted(attrs.items())),tuple(resolved),tuple(canon(c) for c in xf))

    def tables(self):
        return {e.get('name'): e for p,e in self.xml.items() if p.startswith('xl/tables/') and p.endswith('.xml')}

    def charts(self):
        return [e for p,e in sorted(self.xml.items()) if e.tag=='{'+NS['c']+'}chartSpace']

    def semantic_part(self, part, strip_caches=False):
        el=copy.deepcopy(self.xml[part])
        relationships=self.relationships(part)
        for node in el.iter():
            for key,value in list(node.attrib.items()):
                if key.startswith(R) and value in relationships:
                    # Relationship IDs are serialization details. Compare the
                    # linked target, not an auto-generated identifier.
                    node.set(key,relationships[value])
        return canon(el,strip_caches)


class Checks:
    def __init__(self):
        self.total, self.failed, self.unverified = 0, [], []

    def check(self, condition, name, detail=None):
        self.total += 1
        if not condition and len(self.failed) < 100:
            self.failed.append({'check':name,'detail':detail})

    def value(self, wb, sheet, address, expected, tolerance=1e-7):
        cell = wb.get(sheet,address)
        actual = cell['value']
        if actual is None and cell['formula'] is not None and expected not in {'',None}:
            self.total += 1
            if len(self.unverified) < 100:
                self.unverified.append({'check':f'{sheet}!{address}','reason':'Formula has no cached value; recalculate and save in the declared engine.'})
            return
        if expected in ('',None):
            ok = actual in ('',None)
        elif isinstance(expected,(int,float)):
            ok = isinstance(actual,(int,float)) and math.isclose(actual,expected,abs_tol=tolerance,rel_tol=0)
        else:
            ok = actual == expected
        self.check(ok,f'{sheet}!{address}',{'expected':expected,'actual':actual})

    def matrix(self, wb, sheet, start, rows, date_columns=(), tolerance=1e-7):
        for r,values in enumerate(rows,start):
            for c,value in enumerate(values,1):
                if c in date_columns:
                    value = serial(value)
                self.value(wb,sheet,f'{colname(c)}{r}',value,tolerance)

    def formulas(self, wb, sheet, rows, columns):
        for row in rows:
            for column in columns:
                a = f'{column}{row}'
                self.check(bool(wb.get(sheet,a)['formula']), f'Live formula at {sheet}!{a}')


def simulate_inventory(spec, extra_safety=0):
    stocks = copy.deepcopy(spec['stock'])
