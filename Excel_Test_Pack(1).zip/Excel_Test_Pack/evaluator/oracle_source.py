"""Deterministic synthetic fixtures and independent Decimal answer oracles."""
import csv, json, random, sqlite3
from pathlib import Path
from datetime import date
from decimal import Decimal as D, ROUND_HALF_UP
ROOT=Path(__file__).resolve().parents[1]; PACK=ROOT
def write_csv(path,headers,rows):
    with path.open('w',newline='') as f:
        w=csv.writer(f); w.writerow(headers); w.writerows(rows)
def money(v): return float(D(str(v)).quantize(D('.01'),rounding=ROUND_HALF_UP))
def rnd(v): return int(D(str(v)).quantize(D('1'),rounding=ROUND_HALF_UP))
def dump(path,obj): path.write_text(json.dumps(obj,indent=2))
MONTHS=[f'2026-{m:02}-01' for m in range(1,13)]
REGIONS=['Central','East','West','North']
SKUS=[f'{s:04}' for s in range(1,9)]
PRODUCTS=[[s,f'Industrial component {i+1}',160+i*20,95+i*13,.6+i*.07,200+i*15] for i,s in enumerate(SKUS)]
OPENING=[[s,1000+i*45,p[5]] for i,(s,p) in enumerate(zip(SKUS,PRODUCTS))]
rng=random.Random(260109)
orders=[]
for i in range(3000):
    p=PRODUCTS[i%8]; m=(i//32)%6+1; region=REGIONS[(i//8)%4]
    q=rng.randint(1,7)*(-1 if i%41==0 else 1); price=p[2]; discount=[0,.02,.05][i%3]
    posted=money(D(q)*D(price)*(1-D(str(discount))))
    orders.append([f'INV{i:05}',f'2026-{m:02}-{i%27+1:02}',MONTHS[m-1],p[0],region,q,price,discount,posted])
supply=[]; demand=[]
for i,p in enumerate(PRODUCTS):
    for m in range(1,13):
        planned=220+i*10 if m<=6 else 390+i*18
        supply.append([p[0],MONTHS[m-1],planned,0 if i==6 and m==9 else None])
    for j,region in enumerate(REGIONS):
        for m in range(7,13): demand.append([p[0],region,MONTHS[m-1],140+i*9+j*12+(m-7)*15,p[2]])
assert supply[54][0]=='0005' and supply[54][1]==MONTHS[6] # Excel row59
M1={'products':PRODUCTS,'opening':OPENING,'orders':orders,'supply':supply,'demand':demand,'months':MONTHS,'regions':REGIONS}
# M1 data stays in memory; the XLSX is supplied as a fixture.
def calc_m1(changed=False,case=1,uplift=.12,first_rate=.01):
    ps={p[0]:p for p in PRODUCTS}; dm={(r[0],r[1],r[2]):r[3] for r in demand}; hist={}
    for r in orders:
        k=(r[3],r[4],r[2]); old=hist.get(k,[0,0]); hist[k]=[old[0]+r[5],old[1]+r[8]]
    inv={}; purchases={}; sales={}; rebates={}; op={}; cash={}
    for sku_i,sku in enumerate(SKUS):
        opening=OPENING[sku_i][1]; p=ps[sku]
        for month_i,month in enumerate(MONTHS):
            actual=month_i<6; factor=1 if actual else (1.02 if case==1 else 1.05)
            sup=supply[sku_i*12+month_i]; planned=700 if changed and sku=='0005' and month_i==6 else sup[2]
            receipt=sup[3] if sup[3] is not None else planned; cost=p[3]*factor
            purchases[(sku,month)]=[sku,month,planned,receipt,cost,receipt*cost]
            desired=[]; prices=[]; lifts=[]
            for region in REGIONS:
                if actual:
                    units,rev=hist.get((sku,region,month),[0,0]); desired.append(units); prices.append(rev/units if units else 0); lifts.append(0)
                else:
                    lift=uplift if changed and sku in ('0001','0003') and region=='East' and month_i>=7 else (.03 if case==1 else .01)
                    desired.append(rnd(dm[(sku,region,month)]*(1 if case==1 else .85)*(1-p[4]*lift)))
                    prices.append(p[2]*(1+lift)); lifts.append(lift)
            total=sum(desired); avail=opening+receipt; fulfill=min(total,avail); ratio=fulfill/total if total else 1; ending=avail-fulfill
            inv[(sku,month)]=[sku,month,opening,receipt,total,avail,fulfill,max(0,total-avail),ending,p[5],max(0,p[5]-ending),ratio,fulfill*cost]
            for j,region in enumerate(REGIONS):
                units=desired[j] if actual else desired[j]*ratio; rev=hist.get((sku,region,month),[0,0])[1] if actual else units*prices[j]
                base=hist.get((sku,region,month),[0,0])[0] if actual else dm[(sku,region,month)]
                sales[(sku,region,month)]=[sku,region,month,base,lifts[j],desired[j],units,prices[j],rev,cost,units*cost,rev-units*cost]
            opening=ending
    for region in REGIONS:
        for mi,month in enumerate(MONTHS):
            gross=sum(sales[(s,region,month)][8] for s in SKUS)
            rebate=(min(gross,100000)*first_rate+min(max(gross-100000,0),200000)*.02+max(gross-300000,0)*.03) if changed and mi>=8 else gross*.02
            rebates[(region,month)]=[region,month,gross,rebate,gross-rebate,rebate/gross if gross else 'n.a.']
    dashboard=[]; previous_cash=200000; previous_net=0; previous_purchase=0
    for mi,month in enumerate(MONTHS):
        gross=sum(rebates[(r,month)][2] for r in REGIONS); rebate=sum(rebates[(r,month)][3] for r in REGIONS); net=gross-rebate
        storage=sum(inv[(s,month)][8] for s in SKUS)*1.2; expense=net*.015+storage+20000+6000
        op[month]=[month,net,net*.015,storage,20000,6000,expense]
        collection=net*.8+(12000 if mi==0 else previous_net*.2); payment=9000 if mi==0 else previous_purchase
        net_cash=collection-payment-expense; close=previous_cash+net_cash
        cash[month]=[month,previous_cash,collection,payment,expense,net_cash,close]
        cogs=sum(inv[(s,month)][12] for s in SKUS); unmet=sum(inv[(s,month)][7] for s in SKUS)
        dashboard.append([date(2026,mi+1,1).strftime('%b'),gross,rebate,net,cogs,expense,net-cogs-expense,close,unmet])
        previous_cash=close; previous_net=net; previous_purchase=sum(purchases[(s,month)][5] for s in SKUS)
    region_rows=[]
    for region in REGIONS:
        for month in MONTHS:
            rb=rebates[(region,month)]; cogs=sum(sales[(s,region,month)][10] for s in SKUS); units=sum(sales[(s,region,month)][6] for s in SKUS)
            region_rows.append([region,month,rb[2],rb[3],rb[4],cogs,rb[4]-cogs,(rb[4]-cogs)/rb[4] if rb[4] else 'n.a.',units])
    return {'Sales':list(sales.values()),'Inventory':list(inv.values()),'Purchasing':list(purchases.values()),'Rebates':list(rebates.values()),'OperatingCosts':list(op.values()),'Cashflow':list(cash.values()),'RegionView':region_rows,'Dashboard':dashboard,'cards':[sum(r[3] for r in dashboard),sum(r[6] for r in dashboard),dashboard[-1][7]]}
# Sales dictionary insertion order above is SKU/month/region. Workbook contract is SKU/region/month.
def reorder(result):
    result['Sales'].sort(key=lambda r:(r[0],REGIONS.index(r[1]),r[2])); return result
m1_states={name:reorder(calc_m1(**args)) for name,args in {'source':{},'base':{'changed':True},'downside':{'changed':True,'case':2},'price08':{'changed':True,'uplift':.08},'tier015':{'changed':True,'first_rate':.015}}.items()}
dump(PACK/'evaluator/m1_expected.json',m1_states)

# Dashboard sources. All data and rates are explicitly fictional.
folder=PACK/'agent_inputs/D50K'; cats=['Accessories','Components','Devices','Equipment','Services','Supplies']; channels=['Online','Retail','Wholesale']; segments=['Enterprise','SMB','Consumer']
products=[[f'{i+1:06}',f'Product {i+1:02}',cats[i%6],250+i*10] for i in range(60)]
customers=[[f'C{i+1:05}',segments[i%3],'2026-01-01'] for i in range(400)]
customers += [[f'C{i+1:05}',segments[(i+1)%3],'2026-06-01'] for i in range(0,400,29)]
customer_map={r[0]:r[1] for r in sorted(customers,key=lambda r:r[2])}; product_map={r[0]:r for r in products}
fx=[]
for m in range(1,13):
    for c,rate in [('SAR',1),('USD',3.75),('EUR',4+(m-1)*.01)]:
        if not(m==7 and c=='EUR'): fx.append([f'2026-{m:02}',c,round(rate,2)])
fxmap={(r[0],r[1]):D(str(r[2])) for r in fx}
budgets=[[f'2026-{m:02}',region,2600000+m*220000+ri*180000] for m in range(1,13) for ri,region in enumerate(REGIONS)]
headers=['order_id','line_id','date','region','channel','customer_id','sku','quantity','unit_price','discount','status','currency']
rng=random.Random(20261009); raw=[]; order_dims={}
for i in range(50000):
    if i and i%137==0: raw.append(raw[-1].copy()); continue
    oi=i//3
    if oi not in order_dims:
        m=rng.randint(1,12); cust=f'C{rng.randint(1,400):05}'; order_dims[oi]=[f'2026-{m:02}-{rng.randint(1,28):02}',rng.choice(REGIONS),rng.choice(channels),cust]
    dt,region,channel,cust=order_dims[oi]; pi=rng.randrange(60)
    if region=='North' and channel=='Wholesale' and customer_map[cust]=='Consumer' and cats[pi%6]=='Services': pi=(pi+1)%60
    currency=rng.choice(['SAR','SAR','USD','EUR']); status='cancelled' if i%31==0 else ('returned' if i%17==0 else 'completed'); qty=rng.randint(0,9)
    price=D(rng.randint(10000,95000))/100; price_text=f'{price:,.2f}' if i%89==0 else str(price)
    discount='' if i%19==0 else ('1' if i%211==0 else str(D(rng.randrange(0,21))/100))
    row=[f'O{oi:06}',str(i%3+1),dt,region,channel,cust,products[pi][0],str(qty),price_text,discount,status,currency]
    if i%223==0: row[6]='999999'
    if i%227==0: row[5]='C99999'
    if i%229==0: row[11]='GBP'
    if i%233==0: row[8]=''
    raw.append(row)
write_csv(folder/'transactions_50000.csv',headers,raw)
write_csv(folder/'products.csv',['sku','product','category','unit_cost_sar'],products)
write_csv(folder/'customers.csv',['customer_id','segment','updated_at'],customers)
write_csv(folder/'fx_rates.csv',['month','currency','sar_per_unit'],fx)
write_csv(folder/'budgets.csv',['month','region','budget_net_sales_sar'],budgets)
seen=set(); fact=[]; rejected=[]
for idx,row in enumerate(raw,2):
    oid,lid,dt,region,channel,cust,sku,qty,price,discount,status,currency=row; key=(oid,lid)
    reason='duplicate' if key in seen else ('cancelled' if status=='cancelled' else ('unknown_sku' if sku not in product_map else ('unknown_customer' if cust not in customer_map else ('missing_fx' if (dt[:7],currency) not in fxmap else ('missing_price' if not price else None)))))
    seen.add(key)
    if reason: rejected.append([idx,oid,lid,reason]); continue
    q=D(qty)*(-1 if status=='returned' else 1); p=D(price.replace(',','')); dis=D(discount or '0'); rate=fxmap[(dt[:7],currency)]; cost=D(str(product_map[sku][3]))
    revenue=(q*p*(1-dis)*rate).quantize(D('.01'),rounding=ROUND_HALF_UP); cogs=q*cost
    fact.append([oid,lid,dt,region,channel,cust,customer_map[cust],sku,product_map[sku][2],float(q),float(p),float(dis),currency,float(rate),float(cost),float(revenue),float(cogs),float(revenue-cogs),float(max(revenue,0)),float(max(-revenue,0))])
fact_headers=['order_id','line_id','date','region','channel','customer_id','segment','sku','category','signed_quantity','unit_price_local','discount','currency','fx','unit_cost_sar','net_sales_sar','cogs_sar','gross_profit_sar','sale_value_sar','return_value_sar']
write_csv(PACK/'evaluator/fact_expected.csv',fact_headers,fact)
write_csv(PACK/'evaluator/rejected_expected.csv',['raw_row','order_id','line_id','reason'],rejected)
def aggregate(rows,controls):
    lo,hi=controls['StartMonth'][:7],controls['EndMonth'][:7]
    match=[r for r in rows if lo<=r[2][:7]<=hi and all(controls[n]=='All' or controls[n]==r[col] for n,col in [('SelectedRegion',3),('SelectedChannel',4),('SelectedSegment',6),('SelectedCategory',8)])]
    def total(rs,col): return float(sum((D(str(r[col])) for r in rs),D(0)))
    def ratio(a,b): return a/b if b else 'n.a.'
    net=total(match,15); gp=total(match,17); sale=total(match,18); ret=total(match,19)
    available=all(controls[n]=='All' for n in ['SelectedChannel','SelectedSegment','SelectedCategory'])
    budget=sum(r[2] for r in budgets if lo<=r[0]<=hi and controls['SelectedRegion'] in ('All',r[1])) if available else 'n.a.'
    result={'NetSales':net,'GrossProfit':gp,'Margin':ratio(gp,net),'OrderCount':len({r[0] for r in match}),'ActiveCustomers':len({r[5] for r in match}),'NetUnits':total(match,9),'ReturnRate':ratio(ret,sale),'BudgetSales':budget,'BudgetVariance':ratio(net,budget)-1 if isinstance(budget,(int,float)) and budget else 'n.a.','BudgetStatus':'Available' if available else 'Budget not segmented'}
    monthly=[]
    for month in [x[:7] for x in MONTHS]:
        inrange=lo<=month<=hi; rs=[r for r in match if r[2][:7]==month]
        b=sum(r[2] for r in budgets if r[0]==month and controls['SelectedRegion'] in ('All',r[1])) if available and inrange else 'n.a.'
        monthly.append([month,total(rs,15) if inrange else None,total(rs,17) if inrange else None,b])
    def groups(labels,col):
        result=[]
        for label in labels:
            rs=[r for r in match if r[col]==label]; n=total(rs,15); g=total(rs,17); result.append([label,n,g,ratio(g,n)])
        return result
    return {'controls':controls,'kpis':result,'MonthlyView':monthly,'RegionView':groups(REGIONS,3),'CategoryView':groups(cats,8)}
all_control={'SelectedRegion':'All','SelectedChannel':'All','SelectedSegment':'All','SelectedCategory':'All','StartMonth':MONTHS[0],'EndMonth':MONTHS[-1]}
states={}
for name,updates in {'base':{},'east_online_smb_q3':{'SelectedRegion':'East','SelectedChannel':'Online','SelectedSegment':'SMB','StartMonth':MONTHS[6],'EndMonth':MONTHS[8]},'region_only':{'SelectedRegion':'West','StartMonth':MONTHS[3],'EndMonth':MONTHS[5]},'category_detail':{'SelectedChannel':'Retail','SelectedSegment':'Enterprise','SelectedCategory':'Devices','StartMonth':MONTHS[1],'EndMonth':MONTHS[3]},'empty':{'SelectedRegion':'North','SelectedChannel':'Wholesale','SelectedSegment':'Consumer','SelectedCategory':'Services'}}.items():
    states[name]=aggregate(fact,all_control|updates)
mutated=[r.copy() for r in fact]; r=mutated[0]; r[10]+=1; r[15]=money(D(str(r[9]))*D(str(r[10]))*(1-D(str(r[11])))*D(str(r[13]))); r[17]=r[15]-r[16];r[18]=max(r[15],0);r[19]=max(-r[15],0)
states['line_price_change']=aggregate(mutated,all_control)
assert states['empty']['kpis']['OrderCount']==0
counts={'raw':len(raw),'accepted':len(fact),'duplicates':sum(r[3]=='duplicate' for r in rejected),'cancelled':sum(r[3]=='cancelled' for r in rejected),'quarantined':sum(r[3] not in ('duplicate','cancelled') for r in rejected)}
assert sum(counts[k] for k in ['accepted','duplicates','cancelled','quarantined'])==50000
dump(PACK/'evaluator/d50k_expected.json',{'counts':counts,'states':states,'first_fact':fact[0]})
# Independent SQL cross-check of sums/counts/filtering, separate implementation.
db=sqlite3.connect(':memory:');db.execute('CREATE TABLE fact(oid TEXT,lid TEXT,dt TEXT,region TEXT,channel TEXT,customer TEXT,segment TEXT,sku TEXT,category TEXT,qty REAL,price REAL,discount REAL,currency TEXT,fx REAL,cost REAL,net REAL,cogs REAL,gp REAL,sale REAL,ret REAL)');db.executemany('INSERT INTO fact VALUES('+','.join('?'*20)+')',fact)
for name,state in states.items():
    if name=='line_price_change': continue
    c=state['controls']; conditions=['substr(dt,1,7)>=?','substr(dt,1,7)<=?']; args=[c['StartMonth'][:7],c['EndMonth'][:7]]
    for control,col in [('SelectedRegion','region'),('SelectedChannel','channel'),('SelectedSegment','segment'),('SelectedCategory','category')]:
        if c[control]!='All': conditions.append(col+'=?');args.append(c[control])
    res=db.execute('SELECT COALESCE(SUM(net),0),COALESCE(SUM(gp),0),COUNT(DISTINCT oid),COUNT(DISTINCT customer) FROM fact WHERE '+' AND '.join(conditions),args).fetchone()
    for actual,key in zip(res,['NetSales','GrossProfit','OrderCount','ActiveCustomers']): assert abs(actual-state['kpis'][key])<.001,(name,key)
dump(PACK/'operator/data_verification.json',{'seed':20261009,'row_count':50000,'counts':counts,'oracle_sql_crosscheck':'PASS','no_real_customer_data':True,'m1_source_annual_net':m1_states['source']['cards'][0],'m1_requested_annual_net':m1_states['base']['cards'][0]})
print(json.dumps({'counts':counts,'m1_source':m1_states['source']['cards'],'m1_changed':m1_states['base']['cards']},indent=2))
