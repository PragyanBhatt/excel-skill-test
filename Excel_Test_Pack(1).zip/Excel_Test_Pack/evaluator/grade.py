#!/usr/bin/env python3
"""Read-only grader: needs engine-recalculated copies; never calculates Excel formulas."""
import argparse,csv,json,math,re,sys,zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from ooxml import Xlsx,Checks,NS,S,R,canon,serial,colname,addr_parts,translated_formula
ROOT=Path(__file__).resolve().parents[1]
def common(ch,wb):
    ch.check(not any(p.startswith('xl/externalLinks/') or p in ('xl/connections.xml','xl/vbaProject.bin') for p in wb.parts),'No external workbook/data connections or macros')
    for part in wb.parts:
        if part.endswith('.rels'):
            # Get parent part from OOXML relationship path.
            parent=part.replace('/_rels/','/').removesuffix('.rels')
            if parent=='_rels/': parent=''
            for target in wb.relationships(parent).values(): ch.check(target in wb.parts,'Relationship target exists',target)
    for sheet in wb.sheets:
        for a,c in wb.itercells(sheet): ch.check(c['kind']!='e' and '#REF!' not in (c['formula'] or ''),'No formula error '+sheet+'!'+a,c['value'])
def iter_loaded(self,sheet): return iter(self.cells[sheet].items())
Xlsx.itercells=iter_loaded

class StreamXlsx(Xlsx):
    """Stream large sheets. Retain only metadata and shared strings in memory."""
    def __init__(self,path):
        self.path=Path(path);self.zip=zipfile.ZipFile(path);self.parts=set(self.zip.namelist())
        bad=self.zip.testzip()
        if bad: raise ValueError('Corrupt ZIP member '+bad)
        self.xml={p:ET.fromstring(self.zip.read(p)) for p in self.parts if (p.endswith('.xml') or p.endswith('.rels')) and not re.match(r'xl/worksheets/[^/]+\.xml$',p) and p!='xl/sharedStrings.xml'}
        self.shared=[]
        if 'xl/sharedStrings.xml' in self.parts:
            for _,el in ET.iterparse(self.zip.open('xl/sharedStrings.xml'),events=['end']):
                if el.tag==S+'si': self.shared.append(''.join(t.text or '' for t in el.iter(S+'t')));el.clear()
        self.sheets={}; self.cells={}; wb=self.xml['xl/workbook.xml'];rels=self.relationships('xl/workbook.xml');self.sheet_info=[]
        for e in wb.find('s:sheets',NS):
            self.sheets[e.get('name')]=rels[e.get(R+'id')];self.sheet_info.append((e.get('name'),e.get('state','visible')))
        self.names={n.get('name'):canon(n) for n in wb.findall('s:definedNames/s:definedName',NS)}
    def itercells(self,sheet):
        anchors={}
        with self.zip.open(self.sheets[sheet]) as f:
            for _,row in ET.iterparse(f,events=['end']):
                if row.tag!=S+'row': continue
                for el in row.findall('s:c',NS):
                    a=el.get('r');kind=el.get('t');v=el.find('s:v',NS);form=el.find('s:f',NS);value=None if v is None else v.text
                    if kind=='s' and value is not None: value=self.shared[int(value)]
                    elif kind=='inlineStr': value=''.join(t.text or '' for t in el.findall('.//s:t',NS))
                    elif kind=='d' and value: value=serial(value[:10])
                    elif value is not None and kind not in ('str','e'):
                        value=float(value);value=int(value) if value.is_integer() else value
                    formula=None if form is None else (form.text or '')
                    if form is not None and form.get('t')=='shared':
                        si=form.get('si')
                        if formula: anchors[si]=(a,formula)
                        elif si in anchors: formula=translated_formula(anchors[si][1],anchors[si][0],a)
                    yield a,{'value':value,'formula':formula,'kind':kind,'style':int(el.get('s','0'))}
                row.clear()
    def get(self,sheet,address):
        if sheet not in self.cells: self.cells[sheet]=dict(self.itercells(sheet))
        return super().get(sheet,address)
    def table_location(self,name):
        for sheet,part in self.sheets.items():
            for target in self.relationships(part).values():
                el=self.xml.get(target)
                if el is not None and el.tag==S+'table' and el.get('name')==name: return sheet,el
        return None,None
    def table_rows(self,name):
        sheet,t=self.table_location(name)
        if t is None: raise ValueError('Missing native table '+name)
        a,b=t.get('ref').split(':'); c0,r0=addr_parts(a);c1,r1=addr_parts(b);width=c1-c0+1; current=None;values=None
        for address,cell in self.itercells(sheet):
            c,r=addr_parts(address)
            if r<r0 or r>r1 or c<c0 or c>c1:continue
            if r!=current:
                if values is not None:yield current,values
                # Empty whole rows should count as missing records too.
                if current is not None:
                    for missing in range(current+1,r):yield missing,[None]*width
                current=r;values=[None]*width
            values[c-c0]=cell
        if values is not None:yield current,values
        if current is not None:
            for missing in range(current+1,r1+1):yield missing,[None]*width
    def named_location(self,name):
        entries=[e for e in self.xml['xl/workbook.xml'].findall('s:definedNames/s:definedName',NS) if e.get('name')==name and e.get('localSheetId') is None]
        if len(entries)!=1:raise ValueError('Named range '+name+' must exist at workbook scope')
        entry=self.names.get(name);ref='' if entry is None else entry[2].lstrip('=')
        m=re.fullmatch(r"(?:'((?:[^']|'')+)'|([^!]+))!\$?([A-Z]+)\$?(\d+)",ref)
        if not m:raise ValueError('Named range '+name+' must reference one cell; got '+ref)
        return (m[1] or m[2]).replace("''","'"),m[3]+m[4]

def m1_numbers(ch,wb,state):
    truth=json.loads((ROOT/'evaluator/m1_expected.json').read_text())[state]
    for sheet,rows in truth.items():
        if sheet in ('cards',):continue
        datecols=(3,) if sheet=='Sales' else ((1,) if sheet in ('Cashflow','OperatingCosts') else (2,))
        if sheet=='Dashboard':datecols=()
        ch.matrix(wb,sheet,13 if sheet=='Dashboard' else 5,rows,date_columns=datecols,tolerance=.00001)
    for a,v in zip(['B5','E5','H5'],truth['cards']):ch.value(wb,'Dashboard',a,v,.00001)
    for r in range(5,17):
        ch.value(wb,'Audit',f'B{r}',0 if r<11 else 'n.a.',.00001)
        for c in 'CDEFG':ch.value(wb,'Audit',f'{c}{r}',0,.00001)
    if state!='source':
        ch.value(wb,'Assumptions','B4',2 if state=='downside' else 1)
        for a in ['D22','D23']:ch.value(wb,'Assumptions',a,.08 if state=='price08' else .12)
        ch.value(wb,'Assumptions','H22',.015 if state=='tier015' else .01);ch.value(wb,'Supply','C59',700)

def m1_preserve(ch,wb):
    source=Xlsx(ROOT/'agent_inputs/M1/distributor_model.xlsx')
    ch.check(wb.sheet_info==source.sheet_info,'Sheet order, visibility and names preserved')
    def allowed(s,a):
        if (s,a) in {('Assumptions','D22'),('Assumptions','D23'),('Assumptions','A25'),('Supply','C59')}:return True
        c,r=addr_parts(a)
        return (s=='Sales' and c==5 and 5<=r<=388 and (r-5)%12>=6) or (s=='Rebates' and c==4 and 5<=r<=52 and (r-5)%12>=8)
    for sheet,grid in source.cells.items():
        ch.check(sheet in wb.cells,'Preserved sheet '+sheet)
        for a,cell in grid.items():
            now=wb.get(sheet,a)
            if not allowed(sheet,a):
                ch.check(cell['formula']==now['formula'],'Preserved formula '+sheet+'!'+a)
                if cell['formula'] is None:ch.value(wb,sheet,a,cell['value'])
            ch.check(source.style(cell['style'])==wb.style(now['style']),'Preserved formatting '+sheet+'!'+a)
        extras=[a for a,c in wb.cells.get(sheet,{}).items() if a not in grid and (c['formula'] is not None or c['value'] not in ('',None))]
        ch.check(not extras,'No unexpected new content '+sheet,extras[:5])
        original=source.xml[source.sheets[sheet]];now=wb.xml.get(wb.sheets.get(sheet,''))
        # Resolve relationship IDs before comparing sheet metadata.
        def metadata(book,part):
            el=ET.fromstring(book.zip.read(part));rels=book.relationships(part)
            for node in el.iter():
                for k,v in list(node.attrib.items()):
                    if k.startswith(R) and v in rels:node.set(k,rels[v])
            return {e.tag:canon(e) for e in el if e.tag not in (S+'sheetData',S+'dimension')}
        if now is not None:ch.check(metadata(source,source.sheets[sheet])==metadata(wb,wb.sheets[sheet]),'Preserved validation, formatting rules, views and drawing links '+sheet)
    ch.check(source.names==wb.names,'Defined names preserved')
    ch.check({k:canon(v) for k,v in source.tables().items()}=={k:canon(v) for k,v in wb.tables().items()},'Native tables preserved')
    sourcecharts={p for p,e in source.xml.items() if e.tag=='{'+NS['c']+'}chartSpace'}
    ch.check(len(wb.charts())==len(sourcecharts),'Three native charts preserved')
    for p in source.parts:
        if p in sourcecharts or (p.endswith('.xml') and ('/drawings/' in p or '/comments' in p or '/theme/' in p)) or p.endswith('.vml'):
            ch.check(p in wb.parts,'Preserved part '+p)
            if p in wb.xml:ch.check(source.semantic_part(p,True)==wb.semantic_part(p,True),'Preserved chart, drawing or note '+p)
            elif p in wb.parts:ch.check(source.zip.read(p)==wb.zip.read(p),'Preserved non-XML drawing '+p)

def same(ch,actual,expected,label,tol=.011):
    if actual is None:ch.check(expected in (None,''),label,{'actual':actual,'expected':expected});return
    if expected in (None,''):ok=actual in (None,'')
    elif isinstance(expected,(int,float)):ok=isinstance(actual,(int,float)) and math.isclose(actual,expected,abs_tol=tol,rel_tol=0)
    else:ok=actual==expected
    ch.check(ok,label,{'actual':actual,'expected':expected})
def csv_rows(path):
    with path.open(newline='') as f:yield from csv.reader(f)
def compare_table(ch,wb,name,expected,datecols=(),numericcols=(),livecols=(),state='base'):
    actual=iter(wb.table_rows(name));last=None
    for i,row in enumerate(expected):
        got=next(actual,None)
        if got is None:ch.check(False,name+' missing row',i);break
        r,cells=got;last=r
        ch.check(len(cells)==len(row),name+' width')
        for c,v in enumerate(row):
            cell=cells[c] if c<len(cells) and cells[c] else {'value':None,'formula':None}
            if i and c in datecols:v=serial(v)
            elif i and c in numericcols:v=float(v)
            if state=='line_price_change' and name=='SalesFact' and i==1:
                from decimal import Decimal,ROUND_HALF_UP
                first=json.loads((ROOT/'evaluator/d50k_expected.json').read_text())['first_fact'];v=first[c] if c not in (2,) else serial(first[2])
                if c==10:v=first[10]+1
                if c in (15,17,18,19):
                    revenue=float((Decimal(str(first[9]))*Decimal(str(first[10]+1))*(1-Decimal(str(first[11])))*Decimal(str(first[13]))).quantize(Decimal('.01'),rounding=ROUND_HALF_UP))
                    v={15:revenue,17:revenue-first[16],18:max(revenue,0),19:max(-revenue,0)}[c]
            if cell['value'] is None and cell['formula'] and v not in (None,''):ch.unverified.append({'check':name+' cached values','reason':'Recalculate and save; formula cache missing.'}) if len(ch.unverified)<100 else None
            else:same(ch,cell['value'],v,f'{name} row {i} col {c+1}',1e-8 if (name in ('RegionView','CategoryView') and c==3) else (.0000001 if c in (9,10,11,13,14) else .011))
            if i and c in livecols:ch.check(bool(cell['formula']),name+' live row formula')
            if i and c in datecols:ch.check(isinstance(cell['value'],(int,float)),name+' typed date')
    ch.check(next(actual,None) is None,name+' has exactly expected rows')
def d50k_numbers(ch,wb,state,full=True):
    truth=json.loads((ROOT/'evaluator/d50k_expected.json').read_text());target=truth['states'][state]
    for name,value in target['controls'].items():
        sheet,a=wb.named_location(name);ch.value(wb,sheet,a,serial(value) if name in ('StartMonth','EndMonth') else value)
    for name,value in target['kpis'].items():
        sheet,a=wb.named_location(name);ch.value(wb,sheet,a,value,.011 if name in ('NetSales','GrossProfit','BudgetSales') else 1e-8);ch.check(bool(wb.get(sheet,a)['formula']),'Live KPI '+name)
    for name in ['MonthlyView','RegionView','CategoryView']:
        headers={'MonthlyView':['Month','NetSales','GrossProfit','BudgetSales'],'RegionView':['Region','NetSales','GrossProfit','Margin'],'CategoryView':['Category','NetSales','GrossProfit','Margin']}[name]
        compare_table(ch,wb,name,[headers]+target[name],livecols=(1,2,3))
    if full or state=='line_price_change':compare_table(ch,wb,'SalesFact',csv_rows(ROOT/'evaluator/fact_expected.csv'),datecols=(2,),numericcols=(9,10,11,13,14,15,16,17,18,19),livecols=(15,16,17,18,19),state=state)
    if full:
        compare_table(ch,wb,'RawTransactions',csv_rows(ROOT/'agent_inputs/D50K/transactions_50000.csv'))
        for name,file in [('ProductSource','products.csv'),('CustomerSource','customers.csv'),('FxSource','fx_rates.csv'),('BudgetSource','budgets.csv')]:compare_table(ch,wb,name,csv_rows(ROOT/'agent_inputs/D50K'/file))
        compare_table(ch,wb,'Rejected',csv_rows(ROOT/'evaluator/rejected_expected.csv'),numericcols=(0,))
        for name,key in [('RawRows','raw'),('AcceptedRows','accepted'),('DuplicateRows','duplicates'),('CancelledRows','cancelled'),('QuarantinedRows','quarantined')]:
            sheet,a=wb.named_location(name);ch.value(wb,sheet,a,truth['counts'][key])
        for name in ['SelectedRegion','SelectedChannel','SelectedSegment','SelectedCategory']:
            sheet,a=wb.named_location(name);el=ET.fromstring(wb.zip.read(wb.sheets[sheet]));valid=False
            for dv in el.findall('s:dataValidations/s:dataValidation',NS):
                for area in dv.get('sqref','').split():
                    ends=area.split(':');c0,r0=addr_parts(ends[0].replace('$',''));c1,r1=addr_parts(ends[-1].replace('$',''));c,r=addr_parts(a)
                    if c0<=c<=c1 and r0<=r<=r1 and dv.get('type')=='list':valid=True
            ch.check(valid,'Dropdown validation '+name)
        titles=[]
        for chart in wb.charts():
            title=chart.find('.//c:title',NS);titles.append(''.join(t.text or '' for t in ([] if title is None else title.iter()) if t.tag.endswith('}t')))
            refs=[f.text or '' for f in chart.findall('.//c:f',NS)];ch.check(len(refs)>=2,'Chart binds to worksheet cells',refs)
        for title in ['Monthly trend (SAR)','Regional gross profit (SAR)','Category net sales (SAR)','Actual vs budget (SAR)']:ch.check(title in titles,'Native chart '+title,titles)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('case',choices=['M1','D50K']);p.add_argument('output',type=Path);p.add_argument('--calculated-output',type=Path);p.add_argument('--state',action='append',default=[],metavar='NAME=PATH');p.add_argument('--engine-recalculated',action='store_true');p.add_argument('--report',type=Path);args=p.parse_args();ch=Checks()
    try:
        reader=Xlsx if args.case=='M1' else StreamXlsx;original=reader(args.output);common(ch,original)
        if args.case=='M1':m1_preserve(ch,original)
        calculated=reader(args.calculated_output) if args.calculated_output else original
        states=dict(s.split('=',1) for s in args.state);required=['downside','price08','tier015'] if args.case=='M1' else ['east_online_smb_q3','region_only','category_detail','empty','line_price_change']
        if args.case=='M1':m1_numbers(ch,calculated,'base')
        else:d50k_numbers(ch,calculated,'base')
        for name in required:
            if name not in states:ch.unverified.append({'check':'Interaction '+name,'reason':'Missing independent recalculated state copy.'});continue
            book=reader(states[name]);common(ch,book)
            if args.case=='M1':m1_numbers(ch,book,name)
            else:d50k_numbers(ch,book,name,False)
        if not args.engine_recalculated:ch.unverified.append({'check':'Engine recalculation','reason':'Operator attestation missing; this grader does not calculate formulas.'})
        result={'case':args.case,'checks':ch.total,'machine_status':'FAIL' if ch.failed else ('UNVERIFIED' if ch.unverified else 'PASS'),'failures':ch.failed,'unverified':ch.unverified,'manual_review_required':['Native application opens without repair','Readable layout and live assumption/filter controls work','Native chart editability, bindings and visible results','See operator/GRADING.md for case-specific success gates'],'failure_list_limit':100}
    except Exception as e:result={'case':args.case,'machine_status':'ERROR','error':f'{type(e).__name__}: {e}'}
    if args.report:args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));return {'PASS':0,'FAIL':2,'UNVERIFIED':3,'ERROR':1}[result['machine_status']]
if __name__=='__main__':sys.exit(main())
