# Excel skill-impact benchmark: two executable test cases

This pack turns priorities 1 and 3 into controlled tests: modifying a complex existing model, and creating an advanced dashboard from 50,000 transaction lines. It includes real input files, identical agent prompts for both conditions, independent answer oracles, a read-only XLSX grader, interaction tests and paired-run measurement scripts. Data is deterministic and fictional; all rates and SAR amounts are scenario inputs.

**Status:** fixtures and evaluation components are verified. Actual skill-on/no-skill agent trials have not been run. No success, speed, token or cost advantage is claimed. The supplied runner needs an adapter to your existing harness; it does not itself implement an LLM agent. A no-skill condition must truly omit specialized instructions. This authoring session uses the required spreadsheet skill and is not a valid no-skill trial.

| Case | Agent task | Scale and realistic failure modes |
| --- | --- | --- |
| M1: modify existing model | Activate effective-dated regional price overrides, introduce progressive regional rebates, correct one procurement input | 14 functional sheets, 5,777 formulas, 16 tables, 16 names, 3 native charts, 3,000 posted lines. Tests precedence, aggregate-first rules, stock constraints, multi-month cash dependencies, zero-versus-blank inputs and preservation of history/design/objects. |
| D50K: create dashboard | Clean/join five sources and build six-control Excel dashboard with distinct counts and four native charts | Exactly 50,000 source lines, 60 products, 400 customers plus dated snapshot updates, 35 FX rows, 48 budgets. Tests duplicates, returns, missing joins, text IDs, rounding, budget grain, live filters and scalability. |

## Start here

1. Extract the pack. Keep `evaluator/` and `operator/` private. Copy only `agent_inputs/M1/` or `agent_inputs/D50K/` into the agent's isolated `inputs/` directory and send the corresponding exact `prompts/*.md` text. Do not expose this README or the verification/oracle files to the agent.
2. Freeze the model, tools, engine and limits as described in `operator/RUN_CONFIG.md`. Run both conditions with identical prompts and source hashes; only the pinned skill instructions differ. Use fresh sessions and paired randomized order.
3. Keep each original deliverable, recalculate disposable copies in your declared spreadsheet engine, and execute all prescribed edits/filter states in `operator/GRADING.md`. Run `evaluator/grade.py`, then complete manual native-app review.
4. Adjudicate every attempt—including timeouts and unusable outputs—and summarize success, failure modes, actual tokens and elapsed time. Start with three pairs per case, then expand if you want a more stable comparison.

The M1 workbook is `agent_inputs/M1/distributor_model.xlsx`. D50K input files are `transactions_50000.csv`, `products.csv`, `customers.csv`, `fx_rates.csv`, `budgets.csv`. Both cases require an output named `result.xlsx`. Only Python's standard library is required to run the evaluator and operator scripts.

## What success means

All critical correctness, live-update and integrity gates must pass. Machine PASS is necessary but needs native-app confirmation that the workbook opens without repair, has readable layouts and editable charts, and responds to controls. Missing recalculation evidence produces UNVERIFIED. A static dashboard with correct initial numbers fails live-update tests. A numerically correct rebuild that loses M1 objects or history fails preservation. A fast failed attempt still counts as a failure and contributes to attempted cost.

The benchmark has three independent measurements:

| Measurement | Evidence |
| --- | --- |
| Task reliability | Full-record/schedule oracle comparisons, mutation states, source/object preservation, manual critical gates |
| Agent efficiency | Monotonic harness duration and actual provider token counters, including retries and repairs |
| Delivered workbook usability | Open/recalculate behavior, filter responsiveness on fixed hardware, labels/layout and native chart editing |

Do not equate fewer tokens with improvement if reliability falls. The most useful question is whether the skill improves successful delivery and reduces total time/tokens per successful artifact. Paired differences and concrete failure traces make the result explainable.

## Pack contents

- `prompts/`: the two agent task contracts; send unchanged in both conditions.
- `agent_inputs/`: only files the agent should receive.
- `evaluator/`: independent answers, streaming OOXML reader and deterministic checks. Never agent-visible.
- `operator/`: setup, mutation instructions, manual review, example adapter configuration, runner, usage aggregator, adjudication and summary tools.
- `operator/data_verification.json` and `operator/fixture_verification.json`: fixture QA evidence, not agent performance results.
- `operator/input_manifest.json`: SHA-256 source hashes and exact counts.

The answer oracles use Python Decimal with half-up currency rounding and a separate SQLite cross-check for D50K aggregates/distinct counts. M1 full schedules are checked against an independent numerical model. Source XLSX authoring and reference recalculation use the spreadsheet artifact runtime; test Microsoft Excel itself before labeling results Excel-validated. No PowerPoint experiment is included in this focused pack.

`evaluator/oracle_source.py` includes the independent generation/calculation algorithm for audit. Running it regenerates CSV fixtures and answers; use a disposable pack copy and compare source hashes. It does not author or calculate XLSX files. D50K grader logic has positive/negative unit coverage and its data oracle has independent SQL verification; a full native-app D50K reference dashboard has not been built or validated. That creation is the task assigned to each tested agent.

These two tasks probe realistic failure modes but cannot establish a general skill effect across all spreadsheets. Add workbook variations and more paired seeds after the pilot. Publish the frozen task/config versions, all valid attempts, exclusions, engine version and unknown telemetry whenever reporting results.
