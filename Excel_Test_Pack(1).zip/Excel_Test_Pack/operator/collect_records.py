#!/usr/bin/env python3
import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('runs',type=Path);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
rows=[json.loads(f.read_text()) for f in sorted(args.runs.glob('*/run_record.json'))]
args.output.write_text(''.join(json.dumps(r)+'\n' for r in rows));print(f'Collected {len(rows)} run records')
