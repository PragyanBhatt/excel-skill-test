# Private evaluation procedure

Do not expose this directory or `evaluator/` to the agent. Keep the original delivered XLSX unchanged. Use disposable copies for recalculation and mutations. Record the target spreadsheet application/version, operating system, calculation mode and every refresh command. Use a real full recalculation and save, not merely toggling OOXML calculation flags. The Python grader reads cached values; it cannot calculate formulas.

Before the first measured run, open the unmodified M1 source in the declared spreadsheet engine, fully recalculate, and check against the `source` oracle. A source incompatibility invalidates that engine's trial setup; it is not an agent failure. This fixture was verified with the artifact-tool calculation engine, not Microsoft Excel. Preflight Microsoft Excel if Excel is the target. For D50K, confirm that the target environment supports the formula approach chosen by each agent. Tool and engine availability must be identical across conditions.

## M1 states

Finish the task first. Save the original as `delivered.xlsx`. Recalculate a fresh copy to `base.xlsx`. For each state below, start again from the delivered workbook; do not accumulate mutations. Recalculate and save each copy.

| State | Edit after delivery | What it tests |
| --- | --- | --- |
| downside | Assumptions!B4 = 2 | Case propagation; overrides retain precedence; posted history unchanged |
| price08 | Assumptions!D22:D23 = 0.08 | Price/demand elasticity, fulfillment, profit, cash and chart dependencies |
| tier015 | Assumptions!H22 = 0.015 | Progressive logic uses live inputs rather than hardcoded rates |

Base inputs are CaseSelector=1, overrides=.12, first tier=.01, Supply!C59=700. Other source inputs retain their original values. Three changes are deliberately interconnected. Historical cells must remain unchanged even if all forecast formulas recalculate.

```bash
python3 evaluator/grade.py M1 delivered.xlsx --calculated-output base.xlsx \
  --state downside=downside.xlsx --state price08=price08.xlsx \
  --state tier015=tier015.xlsx --engine-recalculated --report M1_report.json
```

Automated checks cover full Sales, Inventory, Purchasing, Rebates, OperatingCosts, Cashflow, RegionView and Dashboard schedules, audit differences, input values, original literals/formulas/styles, sheet order/visibility, tables, names, validation, conditional formatting, views, notes, drawings and chart definitions. Chart caches are excluded from preservation comparisons because values must change. Relationship IDs are resolved to their targets. Equivalent formula rewrites or different XML serialization can still trigger preservation flags: inspect these semantically before attributing failure, document any waived flag, and apply the same rule blind to both conditions.

Manual critical checks: open without a repair warning; all three charts editable and reflecting their updated schedules; note/validation/conditional formatting preserved; no clipped or overlapping elements; January–June historical outputs unchanged. Confirm the real zero override in Supply!D85 still produces zero receipts. Confirm no external workbook links appeared. A chart, name, comment or formatting object silently lost is a preservation failure.

## D50K states

Use the named controls to locate the cells; worksheet layout is intentionally free. Start every state from the delivered workbook. Set all six controls explicitly. Date controls are real Excel dates for the first of each month; the ending month is inclusive.

| State | Region | Channel | Segment | Category | Start | End |
| --- | --- | --- | --- | --- | --- | --- |
| base | All | All | All | All | Jan 1 | Dec 1 |
| east_online_smb_q3 | East | Online | SMB | All | Jul 1 | Sep 1 |
| region_only | West | All | All | All | Apr 1 | Jun 1 |
| category_detail | All | Retail | Enterprise | Devices | Feb 1 | Apr 1 |
| empty | North | Wholesale | Consumer | Services | Jan 1 | Dec 1 |
| line_price_change | All | All | All | All | Jan 1 | Dec 1 |

All dates are 2026. For `line_price_change`, increase unit_price_local in the **first SalesFact body row** by 1, leaving all other fields unchanged. This is an accepted completed line with positive sales value, so the expected totals change. The no-result state is a deliberate valid combination; it must return zero totals/counts and `n.a.` ratios rather than stale data or Excel errors.

```bash
python3 evaluator/grade.py D50K delivered.xlsx --calculated-output base.xlsx \
  --state east_online_smb_q3=east_online_smb_q3.xlsx \
  --state region_only=region_only.xlsx --state category_detail=category_detail.xlsx \
  --state empty=empty.xlsx --state line_price_change=line_price_change.xlsx \
  --engine-recalculated --report D50K_report.json
```

Automated checks cover every raw/master source field, every accepted and rejected record, live Fact formulas, typed dates, all ten KPIs and all chart-helper values in six states, reconciliation counts, dropdown existence, four native chart titles and cell bindings. Large sheets are streamed to limit memory. Monetary tolerance is 0.011 SAR per row/aggregate; counts are exact and KPI ratios use 1e-8 tolerance. No missing state earns an automatic pass.

Manual critical checks: opens without repair; categorical dropdowns offer every valid choice including All; month controls behave as inclusive months; each chart's series and category bindings refer to the intended helper columns and cover every row; charts visibly follow filter/price edits; budget becomes unavailable at finer grain; all four charts are editable, labeled and readable. Verify no external data dependencies or macros. A pasted chart image fails native chart editability.

Record filter and price-edit responsiveness: take three trials of each state from a freshly opened base copy, record edit-to-calculation-complete seconds, and report median and maximum separately from agent harness time. Freeze the interaction SLA before trials; a suggested initial target is ≤5 seconds on a named, fixed machine. Do not conflate load time, agent authoring time and Excel recalculation time.

## Adjudication and failure labels

Machine PASS plus every manual critical gate is required for final success. `UNVERIFIED` means missing evidence, not success; gather the missing engine/state evidence. A timeout, missing deliverable, repair warning, wrong financial totals, lost history, broken live dependency, false distinct count, invalid source reconciliation or lost native objects fails the task. A visually attractive workbook cannot compensate for these failures.

Label failures with one or more of: `data_cleaning`, `calculation`, `dependency`, `distinct_counts`, `budget_grain`, `preservation`, `native_objects`, `layout`, `scalability`, `timeout`, `tool_error`, `invalid_comparison`, `unverified`. Retain traces and concrete failing cells/records. Use blinded artifact IDs for human review; keep condition mapping private until adjudication.

Copy `manual_review.example.json` per run, fill all booleans and notes, then adjudicate. `all_critical_gates_passed` must reflect every case-specific gate above, not appearance alone.

```bash
python3 operator/adjudicate.py runs/M1-p01-skill \
  --machine M1_report.json --manual manual_review.json
python3 operator/collect_records.py runs --output adjudicated_records.jsonl
python3 operator/summarize_runs.py adjudicated_records.jsonl --output comparison.json
```

Failed attempts remain in success-rate denominators and the token/time cost per successful artifact. Invalid experiment setups are reported separately and must be rerun as complete pairs. Unknown usage remains null. Do not remove an expensive failed run or stop measurement when a workbook first appears.
