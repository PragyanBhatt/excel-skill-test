#!/usr/bin/env python3
"""Summarize adjudicated run records, including failures and unknown telemetry."""
import argparse,json,statistics
from collections import defaultdict
from pathlib import Path
def summary(rows):
    valid=[r for r in rows if r['comparison_valid']];adjudicated=[r for r in valid if isinstance(r.get('final_success'),bool)];wins=[r for r in adjudicated if r['final_success']]
    result={'attempts':len(rows),'valid_attempts':len(valid),'adjudicated':len(adjudicated),'successes':len(wins),'success_rate':len(wins)/len(adjudicated) if adjudicated else None,'invalid_run_ids':[r['run_id'] for r in rows if not r['comparison_valid']]}
    for field in ['harness_elapsed_s','total_tokens','input_tokens','output_tokens']:
        vals=[r.get(field) for r in adjudicated];known=[v for v in vals if v is not None];complete=len(known)==len(vals) and bool(vals)
        result[field]={'known_attempts':len(known),'median_known':statistics.median(known) if known else None,'mean_known':statistics.mean(known) if known else None,'total_all_adjudicated':sum(known) if complete else None,'per_success_including_failed_attempts':sum(known)/len(wins) if complete and wins else None}
    return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('records',type=Path);p.add_argument('--output',type=Path);args=p.parse_args();rows=[json.loads(s) for s in args.records.read_text().splitlines() if s.strip()];groups=defaultdict(list)
    for row in rows:groups[(row['case'],row['condition'])].append(row)
    out={'groups':{case+':'+condition:summary(rs) for (case,condition),rs in sorted(groups.items())},'paired_differences':{},'note':'Positive success difference favors skill. Negative time/token difference favors skill. Small pilot samples do not establish general performance.'}
    pairs=defaultdict(dict)
    for row in rows:pairs[(row['case'],row['pair_id'])][row['condition']]=row
    for case in ['M1','D50K']:
        diffs=defaultdict(list);discordant={'skill_only_success':0,'no_skill_only_success':0}
        for (cid,pid),pair in pairs.items():
            if cid!=case or not all(k in pair for k in ['skill','no_skill']):continue
            a,b=pair['skill'],pair['no_skill']
            if not all(r['comparison_valid'] and isinstance(r.get('final_success'),bool) for r in [a,b]):continue
            diffs['success'].append(int(a['final_success'])-int(b['final_success']))
            if a['final_success'] and not b['final_success']:discordant['skill_only_success']+=1
            if b['final_success'] and not a['final_success']:discordant['no_skill_only_success']+=1
            for field in ['harness_elapsed_s','total_tokens']:
                if a.get(field) is not None and b.get(field) is not None:diffs[field].append(a[field]-b[field])
        out['paired_differences'][case]={**discordant,**{field:{'pairs':len(v),'mean_skill_minus_no_skill':statistics.mean(v),'median_skill_minus_no_skill':statistics.median(v)} for field,v in diffs.items()}}
    if args.output:args.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
