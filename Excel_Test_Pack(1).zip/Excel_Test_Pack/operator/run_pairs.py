#!/usr/bin/env python3
"""Launch an existing harness adapter in fresh paired workspaces. Does not implement an LLM harness."""
import argparse,hashlib,json,os,random,shutil,signal,subprocess,time
from pathlib import Path
from aggregate_usage import aggregate
ROOT=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run_one(config,case,pair,condition,runs):
    run_id=f'{case}-p{pair:02}-{condition}';work=runs/run_id;work.mkdir(parents=True,exist_ok=False);inputs=work/'inputs';shutil.copytree(ROOT/'agent_inputs'/case,inputs)
    request={'run_id':run_id,'case':case,'pair_id':f'{case}-p{pair:02}','condition':condition,'prompt':(ROOT/'prompts'/f'{case}.md').read_text(),'input_files':[str(p.resolve()) for p in sorted(inputs.iterdir()) if p.is_file()],'output_file':str((work/'result.xlsx').resolve()),'response_file':str((work/'response.json').resolve()),'session_attestation_file':str((work/'session_attestation.json').resolve()),'usage_jsonl':str((work/'calls_usage.jsonl').resolve()),'model_id':config['model_id'],'model_settings':config['model_settings'],'tools_fingerprint':config['tools_fingerprint'],'limits':config['limits'][case],'skill':{'id':config['skill_id'],'enabled':condition=='skill'},'input_sha256':{p.name:digest(p) for p in inputs.iterdir() if p.is_file()}}
    request_path=work/'request.json';request_path.write_text(json.dumps(request,indent=2));argv=[arg.replace('{request}',str(request_path.resolve())) for arg in config['adapter_command']]
    start=time.monotonic();status='adapter_error';code=None
    with (work/'adapter.log').open('wb') as log:
        try:
            proc=subprocess.Popen(argv,cwd=work,start_new_session=True,stdout=log,stderr=subprocess.STDOUT)
            try:code=proc.wait(timeout=request['limits']['wall_seconds']);status='completed' if code==0 else 'adapter_error'
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL);proc.wait();status='timeout'
        except OSError as error:log.write(str(error).encode())
    elapsed=time.monotonic()-start;response={};attestation={};issues=[];telemetry_issues=[]
    if (work/'response.json').exists():
        try:response=json.loads((work/'response.json').read_text())
        except ValueError:issues.append('invalid response.json')
    if (work/'session_attestation.json').exists():
        try:attestation=json.loads((work/'session_attestation.json').read_text())
        except ValueError:issues.append('invalid session_attestation.json')
    for key,expected in [('model_id',config['model_id']),('tools_fingerprint',config['tools_fingerprint']),('skill_loaded',condition=='skill'),('skill_id',config['skill_id'])]:
        if attestation.get(key)!=expected:issues.append('attestation mismatch: '+key)
    if attestation.get('other_specialized_skills_loaded')!=[]:issues.append('other specialized skills were loaded or not attested')
    if attestation.get('limits_enforced') is not True:issues.append('adapter did not attest call/token limits')
    if attestation.get('fresh_session') is not True:issues.append('fresh session not attested')
    for name,value in request['input_sha256'].items():
        if not (inputs/name).exists() or digest(inputs/name)!=value:issues.append('input was modified: '+name)
    usage={'llm_calls':None,'input_tokens':None,'output_tokens':None,'total_tokens':None,'cached_input_tokens':None,'reasoning_output_tokens':None,'usage_complete':False}
    try:
        if (work/'calls_usage.jsonl').exists():
            records=[json.loads(line) for line in (work/'calls_usage.jsonl').read_text().splitlines() if line.strip()];usage=aggregate(records)
            if not response.get('usage_exhaustive',False):
                telemetry_issues.append('telemetry not attested exhaustive; partial counters retained separately')
                usage={'partial_usage':usage,**{k:None for k in ['llm_calls','input_tokens','output_tokens','total_tokens','cached_input_tokens','reasoning_output_tokens']},'usage_complete':False}
    except (ValueError,KeyError) as error:
        telemetry_issues.append('usage invalid: '+str(error));usage={k:None for k in ['llm_calls','input_tokens','output_tokens','total_tokens','cached_input_tokens','reasoning_output_tokens']};usage['usage_complete']=False
    if usage.get('llm_calls') is not None and usage['llm_calls']>request['limits']['llm_calls']:issues.append('LLM-call cap exceeded')
    if usage.get('total_tokens') is not None and usage['total_tokens']>request['limits']['total_tokens']:issues.append('total-token cap exceeded')
    result={'run_id':run_id,'case':case,'pair_id':request['pair_id'],'condition':condition,'status':status,'exit_code':code,'harness_elapsed_s':elapsed,'artifact_exists':(work/'result.xlsx').is_file(),'comparison_valid':not issues,'validity_issues':issues,'telemetry_issues':telemetry_issues,**usage,'machine_status':None,'manual_success':None,'final_success':None,'response':response,'session_attestation':attestation}
    (work/'run_record.json').write_text(json.dumps(result,indent=2));return result
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('config',type=Path);p.add_argument('--runs',type=Path,required=True);args=p.parse_args();config=json.loads(args.config.read_text());runs=args.runs.resolve();runs.mkdir(parents=True,exist_ok=True)
    if '{request}' not in '\n'.join(config['adapter_command']):raise ValueError('adapter_command must include {request}')
    if any('PIN' in str(config[k]) for k in ['model_id','tools_fingerprint','skill_id','model_settings']):raise ValueError('Replace all PIN placeholders before running')
    pairs=config['pairs_per_case'];rng=random.Random(config['random_seed']);queue=[]
    for case in ['M1','D50K']:
        orders=[['skill','no_skill'] if i%2==0 else ['no_skill','skill'] for i in range(pairs)];rng.shuffle(orders)
        for pair,order in enumerate(orders,1):queue.append((case,pair,order))
    rng.shuffle(queue)
    with (runs/'run_records.jsonl').open('x') as f:
        for case,pair,order in queue:
            for condition in order:
                result=run_one(config,case,pair,condition,runs);f.write(json.dumps(result)+'\n');f.flush();print(json.dumps({k:result[k] for k in ['run_id','status','harness_elapsed_s','comparison_valid','usage_complete']}),flush=True)
if __name__=='__main__':main()
