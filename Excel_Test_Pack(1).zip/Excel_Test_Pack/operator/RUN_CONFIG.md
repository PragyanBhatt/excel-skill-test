# Controlled skill ablation

These are two matched Excel tasks. The treatment is access to one pinned specialized spreadsheet skill's instructions. It is not a comparison of different models, tools, token budgets or spreadsheet libraries.

Use the same exact model/version, sampling/reasoning settings, base system/developer instructions, user prompt, source bytes, available tools/schemas, runtime packages, file/network permissions, application engine and limit policy in both conditions. Keep the skill's runtime dependencies available in both conditions. Skill-on loads the pinned skill instructions; no-skill disables their loading/injection, discovery and retrieval, including spreadsheet guidance inherited from earlier messages. No-skill is invalid if its platform automatically includes equivalent specialized instructions. Merely asking a model to ignore a loaded skill does not establish a no-skill condition.

Create fresh conversations, sandboxes, memory and caches per run. Prevent evaluator/operator access through tool permissions; copying inputs into a fresh directory alone is not filesystem isolation. Do not share traces, outputs, attempts or answers across conditions. Do not give either condition the oracles, source builder, mutation states, grader or expected counts. The shared user prompt includes acceptance contracts but does not include answers.

Start with **three pairs per case** (12 agent attempts). Alternate which condition runs first and randomize pair ordering; record the schedule. This is a pilot for finding failure modes. Expand to at least ten pairs per case for a more useful task-specific comparison, with confidence intervals if making claims. Two tasks do not establish general Excel performance. Freeze limits before looking at outcomes; example limits are 10 minutes M1, 20 minutes D50K, 30 LLM calls and 100,000 total tokens per attempt. Run a separate excluded shakedown to verify these are feasible for your harness. Identical caps can expose efficiency differences; report any truncation caused by caps.

## Adapter contract

`run_pairs.py` is runnable orchestration around **your existing harness adapter**, not a bundled agent service or model API implementation. Edit `run_config.example.json` with an absolute adapter command and pinned values; keep the config outside agent-accessible directories. The adapter gets `--request /absolute/request.json` (or your equivalent command argument). It must read the request, configure the condition, enforce call/token caps and run the identical prompt. The runner enforces the wall-time cap and copies only the appropriate input fixture.

Before the first model call, write `session_attestation.json` at the supplied path with:

```json
{
  "model_id": "same exact ID as request",
  "tools_fingerprint": "same exact fingerprint as request",
  "skill_id": "same pinned skill ID/version as request",
  "skill_loaded": true,
  "other_specialized_skills_loaded": [],
  "fresh_session": true,
  "limits_enforced": true
}
```

Set skill_loaded=false in no-skill. This starting attestation is necessary so legitimate timeouts remain valid failed attempts even when no final response exists. Retain the actual injected instructions, tool schemas and runtime manifest as private audit evidence; attestations alone do not establish a clean ablation. Do not show condition/config metadata to the model beyond enabling the actual skill treatment.

Save `result.xlsx` at the supplied output path. Inputs are immutable; modify a copy for M1. Write `response.json` on completion, including `usage_exhaustive: true` only if all provider calls—including retries, failed billable calls, internal verification/repair and any allowed agent delegation—are captured. Delegation policy must be identical across conditions. If usage is incomplete, omit/false that field and explain missing data. Always append call telemetry incrementally so timeouts retain whatever usage is available.

`calls_usage.jsonl` has one unique record per actual provider call:

```json
{"call_id":"unique-provider-call-id","usage":{"input_tokens":1250,"output_tokens":470,"total_tokens":1720,"cached_input_tokens":300,"reasoning_output_tokens":null}}
```

These numbers illustrate the schema only; they are not benchmark measurements. Map provider-specific counters correctly. Cached input and reasoning output are subsets, not additional tokens. Include skill instructions in input usage when they are sent to the provider. Preserve raw usage alongside normalized records. Do not infer token counts from text length, convert unavailable counters to zero, or drop failed calls. Monetary cost requires actual billing or a dated price configuration; this pack does not invent cost estimates.

```bash
python3 operator/run_pairs.py operator/run_config.json --runs /absolute/private/runs
```

Harness time is measured monotonically from adapter launch to completion, including context/skill setup, model/tool calls, validation and repair. Input staging and external grading are outside this time and reported separately. The runner is sequential to reduce resource contention. It kills only its own process group on timeout. Isolation, provider logging and precise skill switching are the adapter's responsibilities. Missing/wrong starting attestation marks the comparison invalid; missing usage is a measurement limitation and does not erase a task failure.

Report, separately for M1 and D50K: all attempts, valid/adjudicated attempts, success rate, failure labels, median/mean time and tokens, paired skill-minus-no-skill differences, and total attempted time/tokens divided by successful artifacts. Include failed attempts in this cost. Zero successful artifacts makes cost per success undefined. Show unknown telemetry counts. Use overall totals only as a clearly labeled aggregate, never to hide a worse individual case.
