#!/usr/bin/env python3
import argparse,json
from pathlib import Path
GATES=['opens_without_repair','native_chart_editability_and_correct_bindings','controls_and_live_updates','case_specific_integrity_and_preservation','readable_layout','self_contained_no_external_links','interaction_sla_met','all_critical_gates_passed']
def main():
    p=argparse.ArgumentParser();p.add_argument('run',type=Path);p.add_argument('--machine',type=Path);p.add_argument('--manual',type=Path);args=p.parse_args();path=args.run/'run_record.json';r=json.loads(path.read_text())
    if not r['comparison_valid']:r['final_success']=None;r['failure_labels']=['invalid_comparison']
    elif r['status']!='completed' or not r['artifact_exists']:r['final_success']=False;r['failure_labels']=['timeout' if r['status']=='timeout' else 'tool_error']
    else:
        machine=json.loads(args.machine.read_text()) if args.machine else {};manual=json.loads(args.manual.read_text()) if args.manual else {};r['machine_status']=machine.get('machine_status');r['manual_success']=all(manual.get(k) is True for k in GATES) if all(isinstance(manual.get(k),bool) for k in GATES) else None;r['manual_review']=manual
        if r['machine_status'] in ['FAIL','ERROR'] or r['manual_success'] is False:r['final_success']=False
        elif r['machine_status']=='PASS' and r['manual_success'] is True:r['final_success']=True
        else:r['final_success']=None
        r['failure_labels']=manual.get('failure_labels',[]);r['machine_report']=machine
    path.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r.get(k) for k in ['run_id','machine_status','manual_success','final_success','failure_labels']}))
if __name__=='__main__':main()
