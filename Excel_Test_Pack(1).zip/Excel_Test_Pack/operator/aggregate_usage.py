#!/usr/bin/env python3
"""Aggregate normalized per-call provider usage without estimating missing data.
Usage: python3 operator/aggregate_usage.py call_usage.jsonl --elapsed-s 48.2
Each JSONL record: call_id and usage (input_tokens, output_tokens, total_tokens,
cached_input_tokens, reasoning_output_tokens). Missing/unexposed fields stay null.
Map provider-specific fields in your harness adapter; preserve raw usage separately.
"""
import argparse
import json
from pathlib import Path

FIELDS=['input_tokens','output_tokens','total_tokens','cached_input_tokens','reasoning_output_tokens']


def aggregate(records, exhaustive=False):
    ids=[r['call_id'] for r in records]
    if len(ids)!=len(set(ids)):
        raise ValueError('Duplicate call_id: remove duplicated telemetry, not legitimate retries with distinct IDs.')
    sums={}
    for field in FIELDS:
        values=[r.get('usage',{}).get(field) for r in records]
        for value in values:
            if value is not None and (isinstance(value,bool) or not isinstance(value,int) or value<0):
                raise ValueError(f'{field} must be a nonnegative integer or null')
        sums[field]=sum(values) if records and all(v is not None for v in values) else None
    if sums['total_tokens'] is None and exhaustive and sums['input_tokens'] is not None and sums['output_tokens'] is not None:
        sums['total_tokens']=sums['input_tokens']+sums['output_tokens']
    for r in records:
        u=r.get('usage',{})
        for subset,parent in [('cached_input_tokens','input_tokens'),('reasoning_output_tokens','output_tokens')]:
            if u.get(subset) is not None and u.get(parent) is not None and u[subset]>u[parent]:
                raise ValueError(f'{subset} exceeds {parent}; fix the provider field mapping before aggregation')
    return {'llm_calls':len(records),**sums,'usage_complete':all(sums[f] is not None for f in ['input_tokens','output_tokens','total_tokens'])}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('jsonl',type=Path)
    p.add_argument('--elapsed-s',type=float,help='Actual harness duration from a monotonic timer, not summed call durations')
    p.add_argument('--exhaustive-input-output',action='store_true',help='Use input+output when total is absent; only when provider definitions make this valid')
    args=p.parse_args()
    records=[json.loads(line) for line in args.jsonl.read_text().splitlines() if line.strip()]
    result=aggregate(records,args.exhaustive_input_output)
    result['harness_elapsed_s']=args.elapsed_s
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
